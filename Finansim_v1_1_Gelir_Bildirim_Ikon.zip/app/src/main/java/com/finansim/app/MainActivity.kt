package com.finansim.app

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

private val Navy = Color(0xFF06111C)
private val Panel = Color(0xFF0E2030)
private val Panel2 = Color(0xFF142B3D)
private val Aqua = Color(0xFF20D4CE)
private val Blue = Color(0xFF35A8FF)
private val Muted = Color(0xFF9BB0C1)
private val Red = Color(0xFFFF6474)
private val Green = Color(0xFF37D69A)

data class Debt(val id:String=UUID.randomUUID().toString(), val name:String, val kind:String, val balance:Double,
    val limit:Double=0.0, val statementDay:Int=0, val dueDay:Int=0, val nextPayment:String="", val paid:Boolean=false)
data class Income(val id:String=UUID.randomUUID().toString(), val title:String, val amount:Double, val date:String, val note:String="")

class MainActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState); createChannel(); ReminderScheduler.rescheduleAll(this); setContent { FinansimApp(this) }}
 private fun createChannel(){ getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("finansim_payments","Finansım ödeme hatırlatmaları",NotificationManager.IMPORTANCE_HIGH).apply{description="Ekstre ve ödeme tarihi hatırlatmaları"}) }
}

object ReminderScheduler {
 fun schedule(context:Context, debt:Debt, daysBefore:Int){
   if(debt.nextPayment.isBlank()) return
   try {
    val sdf=SimpleDateFormat("dd.MM.yyyy",Locale("tr","TR")); sdf.isLenient=false
    val due=sdf.parse(debt.nextPayment) ?: return
    val fire=Calendar.getInstance().apply { time=due; add(Calendar.DAY_OF_YEAR,-daysBefore); set(Calendar.HOUR_OF_DAY,9); set(Calendar.MINUTE,0); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0) }
    if(fire.timeInMillis<=System.currentTimeMillis()) return
    val intent=Intent(context,ReminderReceiver::class.java).putExtra("title", "${debt.name} ödeme hatırlatması").putExtra("body", "${debt.nextPayment} tarihinde ${debt.balance.toLong()} TL ödeme görünüyor.")
    val pi=PendingIntent.getBroadcast(context,debt.id.hashCode(),intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    val alarm=context.getSystemService(AlarmManager::class.java)
    alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,fire.timeInMillis,pi)
   }catch (_:Exception){}
 }
 fun rescheduleAll(context:Context){
   val p=context.getSharedPreferences("finansim",Context.MODE_PRIVATE)
   val ds=loadDebts(p.getString("debts","[]")?:"[]")
   val days=p.getInt("reminderDays",1)
   ds.filter{!it.paid}.forEach{schedule(context,it,days)}
 }
}
class ReminderReceiver:BroadcastReceiver(){
 override fun onReceive(context:Context,intent:Intent){
  if(Build.VERSION.SDK_INT>=33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return
  val n=androidx.core.app.NotificationCompat.Builder(context,"finansim_payments").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(intent.getStringExtra("title")?:"Finansım hatırlatma").setContentText(intent.getStringExtra("body")?:"Yaklaşan ödemen var.").setStyle(androidx.core.app.NotificationCompat.BigTextStyle().bigText(intent.getStringExtra("body")?:"Yaklaşan ödemen var.")).setPriority(androidx.core.app.NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).build()
  context.getSystemService(NotificationManager::class.java).notify((System.currentTimeMillis()%100000).toInt(),n)
 }
}
class BootReceiver:BroadcastReceiver(){ override fun onReceive(context:Context,intent:Intent){ if(intent.action==Intent.ACTION_BOOT_COMPLETED) ReminderScheduler.rescheduleAll(context) } }

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun FinansimApp(context:Context){
 val prefs=remember{context.getSharedPreferences("finansim",Context.MODE_PRIVATE)}
 var debts by remember{mutableStateOf(loadDebts(prefs.getString("debts","[]")?:"[]"))}
 var incomes by remember{mutableStateOf(loadIncomes(prefs.getString("incomes","[]")?:"[]"))}
 var tab by remember{mutableIntStateOf(0)}
 var addDebt by remember{mutableStateOf(false)}; var addIncome by remember{mutableStateOf(false)}; var settings by remember{mutableStateOf(false)}
 var reminderDays by remember{mutableIntStateOf(prefs.getInt("reminderDays",1))}
 val permission=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){}
 fun saveDebtsNow(list:List<Debt>){debts=list;prefs.edit().putString("debts",encodeDebts(list)).apply(); list.filter{!it.paid}.forEach{ReminderScheduler.schedule(context,it,reminderDays)}}
 fun saveIncomesNow(list:List<Income>){incomes=list;prefs.edit().putString("incomes",encodeIncomes(list)).apply()}
 val money=remember{NumberFormat.getNumberInstance(Locale("tr","TR")).apply{maximumFractionDigits=0}}
 val openDebt=debts.filter{!it.paid}.sumOf{it.balance}; val totalLimit=debts.sumOf{it.limit}; val usedLimit=debts.filter{it.limit>0}.sumOf{it.balance.coerceAtMost(it.limit)}
 val incomeTotal=incomes.sumOf{it.amount}; val usage=if(totalLimit>0)(usedLimit/totalLimit*100).toInt() else 0
 MaterialTheme(colorScheme=darkColorScheme(primary=Aqua,background=Navy,surface=Panel,onSurface=Color.White)){
  Scaffold(containerColor=Navy, topBar={TopAppBar(title={Row(verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(38.dp).background(Panel2,RoundedCornerShape(12.dp)),contentAlignment=Alignment.Center){Icon(Icons.Default.AccountBalanceWallet,null,tint=Aqua)}; Spacer(Modifier.width(10.dp));Column{Text("Finansım",fontWeight=FontWeight.ExtraBold,fontSize=21.sp);Text("Tüm hesapların, tek yerde",fontSize=11.sp,color=Muted)}}},actions={IconButton(onClick={settings=true}){Icon(Icons.Default.NotificationsActive,null,tint=Aqua)}},colors=TopAppBarDefaults.topAppBarColors(containerColor=Navy,titleContentColor=Color.White)}) ,
   floatingActionButton={FloatingActionButton(onClick={if(tab==1)addIncome=true else addDebt=true},containerColor=Aqua,contentColor=Navy){Icon(Icons.Default.Add,null)}},
   bottomBar={NavigationBar(containerColor=Panel){NavigationBarItem(selected=tab==0,onClick={tab=0},icon={Icon(Icons.Default.Home,null)},label={Text("Ana Sayfa")});NavigationBarItem(selected=tab==1,onClick={tab=1},icon={Icon(Icons.Default.TrendingUp,null)},label={Text("Gelirler")});NavigationBarItem(selected=tab==2,onClick={tab=2},icon={Icon(Icons.Default.CreditCard,null)},label={Text("Borçlar")})}}){pad->
    when(tab){
     0->LazyColumn(Modifier.padding(pad).fillMaxSize().padding(horizontal=16.dp),verticalArrangement=Arrangement.spacedBy(13.dp),contentPadding=PaddingValues(top=8.dp,bottom=90.dp)){
       item{Card(colors=CardDefaults.cardColors(containerColor=Panel2),shape=RoundedCornerShape(24.dp)){Column(Modifier.fillMaxWidth().padding(20.dp)){Text("GENEL FİNANS DURUMUM",color=Muted,fontSize=11.sp,letterSpacing=1.sp);Spacer(Modifier.height(10.dp));Text("${money.format(openDebt)} TL",fontSize=30.sp,fontWeight=FontWeight.Black,color=Color.White);Text("Toplam açık borç",color=Muted,fontSize=12.sp);Spacer(Modifier.height(16.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Metric("Toplam limit","${money.format(totalLimit)} TL");Metric("Kullanılan","${money.format(usedLimit)} TL");Metric("Kullanım","%$usage")};Spacer(Modifier.height(12.dp));LinearProgressIndicator(progress={ (usage/100f).coerceIn(0f,1f)},modifier=Modifier.fillMaxWidth().height(8.dp),color=Aqua,trackColor=Panel)}}}
       item{Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){QuickTile("Gelir ekle",Icons.Default.Add,Aqua,Modifier.weight(1f)){addIncome=true};QuickTile("Hesap ekle",Icons.Default.CreditCard,Blue,Modifier.weight(1f)){addDebt=true};QuickTile("Bildirimler",Icons.Default.NotificationsActive,Green,Modifier.weight(1f)){settings=true}}}
       item{SectionTitle("Bu ayın özeti")}
       item{Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){SummaryCard("Gelir",incomeTotal,Green,Modifier.weight(1f));SummaryCard("Açık borç",openDebt,Red,Modifier.weight(1f))}}
       item{SectionTitle("Yaklaşan ödemeler")}
       val upcoming=debts.filter{!it.paid && it.nextPayment.isNotBlank()}.sortedBy{it.nextPayment}
       if(upcoming.isEmpty())item{InfoCard("Henüz ödeme tarihi eklenmedi","Bir hesaba ödeme tarihi eklediğinde burada görünecek.")}
       items(upcoming.take(5),key={"up"+it.id}){d->PaymentRow(d, money.format(d.balance))}
       item{SectionTitle("Hesapların")}
       if(debts.isEmpty())item{InfoCard("Henüz hesap eklemedin","Kredi kartını, avans hesabını veya kredini + düğmesiyle ekleyebilirsin.")}
       items(debts.take(6),key={it.id}){d->DebtRow(d,money.format(d.balance),onPaid={saveDebtsNow(debts.map{if(it.id==d.id)it.copy(paid=true)else it})},onDelete={saveDebtsNow(debts.filterNot{it.id==d.id})})}
     }
     1->LazyColumn(Modifier.padding(pad).fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp),contentPadding=PaddingValues(bottom=90.dp)){item{Text("Gelirlerim",fontSize=24.sp,fontWeight=FontWeight.Bold)};item{SummaryCard("Kayıtlı toplam gelir",incomeTotal,Green,Modifier.fillMaxWidth())};if(incomes.isEmpty())item{InfoCard("Henüz gelir yok","Maaşını, primini veya ek gelirini + düğmesiyle kaydet.")};items(incomes,key={it.id}){inc->Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(18.dp)){Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(inc.title,color=Color.White,fontWeight=FontWeight.Bold);Text("${inc.date}  ${inc.note}",color=Muted,fontSize=12.sp)};Text("+${money.format(inc.amount)} TL",color=Green,fontWeight=FontWeight.Bold);IconButton(onClick={saveIncomesNow(incomes.filterNot{it.id==inc.id})}){Icon(Icons.Default.Delete,null,tint=Red)}}}}}
     else->LazyColumn(Modifier.padding(pad).fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp),contentPadding=PaddingValues(bottom=90.dp)){item{Text("Kartlarım ve borçlarım",fontSize=24.sp,fontWeight=FontWeight.Bold)};item{InfoCard("Limit ve ekstre takibi","Kredi kartlarında limit, kullanılan tutar, ekstre kesim ve son ödeme gününü kaydedebilirsin. Avans hesaplarını da ayrı takip edebilirsin.")};if(debts.isEmpty())item{InfoCard("Henüz hesap yok","Sağ alttaki + düğmesine basarak hesap ekle.")};items(debts,key={it.id}){d->DebtRow(d,money.format(d.balance),onPaid={saveDebtsNow(debts.map{if(it.id==d.id)it.copy(paid=true)else it})},onDelete={saveDebtsNow(debts.filterNot{it.id==d.id})})}}
    }
   }
  }
  if(addDebt)AddDebtDialog({addDebt=false}){d->saveDebtsNow(debts+d);addDebt=false}
  if(addIncome)AddIncomeDialog({addIncome=false}){i->saveIncomesNow(incomes+i);addIncome=false}
  if(settings)AlertDialog(onDismissRequest={settings=false},title={Text("Bildirim ayarları")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Text("Ödeme tarihinden kaç gün önce hatırlatayım?",color=Muted);Text("$reminderDays gün önce",color=Aqua,fontWeight=FontWeight.Bold);Slider(value=reminderDays.toFloat(),onValueChange={reminderDays=it.toInt().coerceIn(0,7)},valueRange=0f..7f,steps=6);Text("Bildirimler saat 09.00 için planlanır. Android pil tasarrufu bildirim saatini geciktirebilir.",fontSize=12.sp,color=Muted)}},confirmButton={TextButton(onClick={prefs.edit().putInt("reminderDays",reminderDays).apply();ReminderScheduler.rescheduleAll(context);if(Build.VERSION.SDK_INT>=33&&context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)permission.launch(Manifest.permission.POST_NOTIFICATIONS);settings=false}){Text("Kaydet")}},dismissButton={TextButton(onClick={settings=false}){Text("Kapat")}})
 }
}

@Composable fun Metric(label:String,value:String){Column{Text(label,color=Muted,fontSize=10.sp);Text(value,color=Color.White,fontSize=12.sp,fontWeight=FontWeight.Bold)}}
@Composable fun SectionTitle(t:String){Text(t,color=Color.White,fontSize=18.sp,fontWeight=FontWeight.Bold)}
@Composable fun SummaryCard(title:String,value:Double,color:Color,modifier:Modifier){Card(modifier,colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(16.dp)){Text(title,color=Muted,fontSize=12.sp);Text("${NumberFormat.getNumberInstance(Locale("tr","TR")).format(value)} TL",color=color,fontSize=19.sp,fontWeight=FontWeight.Bold)}}}
@Composable fun QuickTile(title:String,icon:androidx.compose.ui.graphics.vector.ImageVector,color:Color,modifier:Modifier,onClick:()->Unit){Card(modifier, onClick=onClick,colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(16.dp)){Column(Modifier.fillMaxWidth().padding(vertical=14.dp),horizontalAlignment=Alignment.CenterHorizontally){Icon(icon,null,tint=color);Spacer(Modifier.height(5.dp));Text(title,color=Color.White,fontSize=11.sp,fontWeight=FontWeight.SemiBold)}}}
@Composable fun InfoCard(title:String,body:String){Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(18.dp)){Text(title,color=Color.White,fontWeight=FontWeight.Bold);Text(body,color=Muted,fontSize=12.sp)}}}
@Composable fun PaymentRow(d:Debt,amount:String){Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(16.dp)){Row(Modifier.fillMaxWidth().padding(14.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Event,null,tint=Aqua);Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(d.name,color=Color.White,fontWeight=FontWeight.Bold);Text("Ödeme: ${d.nextPayment}",color=Muted,fontSize=12.sp)};Text("$amount TL",color=Color.White,fontWeight=FontWeight.Bold)}}}
@Composable fun DebtRow(d:Debt,amount:String,onPaid:()->Unit,onDelete:()->Unit){Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(15.dp)){Row(verticalAlignment=Alignment.CenterVertically){Icon(if(d.kind=="Kredi kartı")Icons.Default.CreditCard else Icons.Default.AccountBalanceWallet,null,tint=Aqua);Spacer(Modifier.width(9.dp));Column(Modifier.weight(1f)){Text(d.name,color=Color.White,fontWeight=FontWeight.Bold);Text(d.kind,color=Muted,fontSize=11.sp)};Text(if(d.paid)"ÖDENDİ" else "AÇIK",color=if(d.paid)Green else Aqua,fontSize=10.sp,fontWeight=FontWeight.Bold)};Spacer(Modifier.height(8.dp));Text("$amount TL",color=Color.White,fontSize=21.sp,fontWeight=FontWeight.Bold);if(d.limit>0)Text("Limit: ${d.limit.toLong()} TL  •  Kullanılabilir: ${(d.limit-d.balance).coerceAtLeast(0.0).toLong()} TL",color=Muted,fontSize=11.sp);if(d.kind=="Kredi kartı")Text("Ekstre: ${d.statementDay}. gün  •  Son ödeme: ${d.dueDay}. gün",color=Muted,fontSize=11.sp);if(d.nextPayment.isNotBlank())Text("Ödeme tarihi: ${d.nextPayment}",color=Muted,fontSize=11.sp);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){if(!d.paid)Button(onClick=onPaid,colors=ButtonDefaults.buttonColors(containerColor=Aqua,contentColor=Navy)){Icon(Icons.Default.Check,null);Text("Ödendi")};TextButton(onClick=onDelete){Text("Sil",color=Red)}}}}}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun AddDebtDialog(onDismiss:()->Unit,onSave:(Debt)->Unit){var name by remember{mutableStateOf("")};var kind by remember{mutableStateOf("Kredi kartı")};var balance by remember{mutableStateOf("")};var limit by remember{mutableStateOf("")};var statement by remember{mutableStateOf("")};var due by remember{mutableStateOf("")};var date by remember{mutableStateOf("")};val kinds=listOf("Kredi kartı","Avans hesap / KMH","İhtiyaç kredisi","Diğer");AlertDialog(onDismissRequest=onDismiss,title={Text("Hesap ekle")},text={Column(Modifier.heightIn(max=520.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){OutlinedTextField(name,{name=it},label={Text("Banka / hesap adı")},singleLine=true);Text("Hesap türü",color=Muted);kinds.chunked(2).forEach{row->Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){row.forEach{k->FilterChip(selected=kind==k,onClick={kind=k},label={Text(k,fontSize=10.sp)})}}};OutlinedTextField(balance,{balance=it},label={Text("Güncel borç (TL)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),singleLine=true);OutlinedTextField(limit,{limit=it},label={Text("Toplam limit (TL)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),singleLine=true);if(kind=="Kredi kartı"){OutlinedTextField(statement,{statement=it},label={Text("Ekstre kesim günü (1-31)")},singleLine=true);OutlinedTextField(due,{due=it},label={Text("Son ödeme günü (1-31)")},singleLine=true)};OutlinedTextField(date,{date=it},label={Text("Sonraki ödeme (GG.AA.YYYY)")},singleLine=true);Text("Bildirim için ödeme tarihi girmen gerekir.",color=Muted,fontSize=11.sp)}},confirmButton={TextButton(enabled=name.isNotBlank()&&balance.toDoubleOrNull()!=null,onClick={onSave(Debt(name=name,kind=kind,balance=balance.toDoubleOrNull()?:0.0,limit=limit.toDoubleOrNull()?:0.0,statementDay=statement.toIntOrNull()?:0,dueDay=due.toIntOrNull()?:0,nextPayment=date.trim()))}){Text("Kaydet")}},dismissButton={TextButton(onClick=onDismiss){Text("Vazgeç")}})}
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun AddIncomeDialog(onDismiss:()->Unit,onSave:(Income)->Unit){var title by remember{mutableStateOf("Maaş")};var amount by remember{mutableStateOf("")};var date by remember{mutableStateOf(SimpleDateFormat("dd.MM.yyyy",Locale("tr","TR")).format(Date()))};var note by remember{mutableStateOf("")};AlertDialog(onDismissRequest=onDismiss,title={Text("Gelir ekle")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(title,{title=it},label={Text("Gelir adı (maaş, prim, ek gelir)")},singleLine=true);OutlinedTextField(amount,{amount=it},label={Text("Tutar (TL)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),singleLine=true);OutlinedTextField(date,{date=it},label={Text("Tarih (GG.AA.YYYY)")},singleLine=true);OutlinedTextField(note,{note=it},label={Text("Not (isteğe bağlı)")},singleLine=true)}},confirmButton={TextButton(enabled=title.isNotBlank()&&amount.toDoubleOrNull()!=null,onClick={onSave(Income(title=title,amount=amount.toDoubleOrNull()?:0.0,date=date,note=note))}){Text("Kaydet")}},dismissButton={TextButton(onClick=onDismiss){Text("Vazgeç")}})}

fun encodeDebts(list:List<Debt>)=JSONArray().apply{list.forEach{d->put(JSONObject().apply{put("id",d.id);put("name",d.name);put("kind",d.kind);put("balance",d.balance);put("limit",d.limit);put("statementDay",d.statementDay);put("dueDay",d.dueDay);put("nextPayment",d.nextPayment);put("paid",d.paid)})}}.toString()
fun loadDebts(raw:String):List<Debt> = try{val a=JSONArray(raw);(0 until a.length()).map{val o=a.getJSONObject(it);Debt(o.optString("id"),o.optString("name"),o.optString("kind"),o.optDouble("balance"),o.optDouble("limit"),o.optInt("statementDay"),o.optInt("dueDay"),o.optString("nextPayment"),o.optBoolean("paid"))}}catch(_:Exception){emptyList()}
fun encodeIncomes(list:List<Income>)=JSONArray().apply{list.forEach{i->put(JSONObject().apply{put("id",i.id);put("title",i.title);put("amount",i.amount);put("date",i.date);put("note",i.note)})}}.toString()
fun loadIncomes(raw:String):List<Income> = try{val a=JSONArray(raw);(0 until a.length()).map{val o=a.getJSONObject(it);Income(o.optString("id"),o.optString("title"),o.optDouble("amount"),o.optString("date"),o.optString("note"))}}catch(_:Exception){emptyList()}
