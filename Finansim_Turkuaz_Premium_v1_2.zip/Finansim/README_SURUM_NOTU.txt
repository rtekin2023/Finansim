FINANSIM 1.2 - TURKUAZ / LACIVERT
- Banka entegrasyonu bulunmaz; banka, kredi ve kart bilgileri manuel girilir.
- PIN kurulumu ve doğrulaması projede bulunur.
- Yerel finansal kayıtlar EncryptedSharedPreferences ile saklanacak şekilde yapılandırılmıştır.
- Android FLAG_SECURE hassas ekranlarda ekran görüntüsü/kaydı engellemeyi etkinleştirir.
- Kredi alanları: faiz oranı, aylık/yıllık faiz türü, vade ayı, taksit, toplam geri ödeme,
  kalan taksit ve erken kapama tutarı.
- Kart alanları: limit, ekstre kesim günü, son ödeme günü, dönem ekstresi ve asgari tutar.
- Şifreli, parola korumalı dışa aktarma/geri yükleme henüz eklenmemiştir.
- Bu kaynak ZIP'i Android cihazda/CI üzerinde henüz derlenip test edilmemiştir.
