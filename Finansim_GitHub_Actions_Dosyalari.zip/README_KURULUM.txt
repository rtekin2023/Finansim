# Finansım Android kaynak projesi

Bu ZIP bir APK değildir; Android Studio ile derlenebilen başlangıç projesidir.

## Derleme
1. Bilgisayara Android Studio (JDK 17 destekli) kur.
2. Bu klasörü Android Studio ile aç.
3. Gradle senkronizasyonunu tamamla.
4. Build > Build Bundle(s) / APK(s) > Build APK(s) seç.
5. Oluşan APK genellikle `app/build/outputs/apk/debug/app-debug.apk` konumunda olur.

## Bu sürümde bulunanlar
- Kredi kartı, KMH/avans hesap, ihtiyaç kredisi ve diğer borç kaydı
- Kart limiti, ekstre kesim günü ve son ödeme günü alanları
- Borç toplamı ve kayıt listesi
- Tek dokunuşla Ödendi işaretleme
- Yerel cihazda SharedPreferences ile saklama

## Henüz bulunmayanlar
- Otomatik zamanlanmış ödeme bildirimleri (bildirim izni ekranı/kanalı hazırlanmış, zamanlayıcı henüz eklenmedi)
- Düzenleme, taksit planı, gelir-gider, dışa aktarma/yedekleme
- Bankalara canlı bağlantı, SMS girişi ve biyometrik kilit

Bu nedenle APK'yı derleyip telefonda test etmeden güvenilir/bitmiş ürün olarak değerlendirme.


## GitHub Actions ile telefondan derleme
1. ZIP içeriğini GitHub'da oluşturduğun boş depoya (repository) yükle.
2. Actions sekmesine gir.
3. "Build Finansim APK" iş akışını seç.
4. "Run workflow" düğmesine bas.
5. İşlem tamamlanınca çalıştırma kaydını aç; Artifacts bölümünden Finansim-debug-apk dosyasını indir.
6. İndirilen APK'yı telefonda açıp Android'in yükleme iznini ver.

Not: Bu workflow APK'yı derlemeyi dener; başarılı derleme APK'nın tüm özelliklerinin test edildiği anlamına gelmez.
