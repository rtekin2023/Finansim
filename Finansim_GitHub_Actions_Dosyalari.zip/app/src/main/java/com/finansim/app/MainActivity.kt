package com.finansim.app

import android.Manifest
import android.app.DatePickerDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Locale
import java.util.UUID

private val Navy = Color(0xFF0B1724)
private val Panel = Color(0xFF142536)
private val Turquoise = Color(0xFF25C9C3)
private val Muted = Color(0xFF9FB2C4)

data class Debt(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val kind: String,
    val balance: Double,
    val limit: Double = 0.0,
    val statementDay: Int = 0,
    val dueDay: Int = 0,
    val nextPayment: String = "",
    val paid: Boolean = false
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createChannel()
        setContent { FinansimApp(this) }
    }
    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("payments", "Ödeme hatırlatmaları", NotificationManager.IMPORTANCE_DEFAULT))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FinansimApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("finansim", Context.MODE_PRIVATE) }
    var debts by remember { mutableStateOf(loadDebts(prefs.getString("debts", "[]") ?: "[]")) }
    var showAdd by remember { mutableStateOf(false) }
    var showPrivacy by remember { mutableStateOf(false) }
    var reminderDays by remember { mutableIntStateOf(prefs.getInt("reminderDays", 3)) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    fun persist(list: List<Debt>) {
        debts = list
        prefs.edit().putString("debts", saveDebts(list)).apply()
    }
    val total = debts.filter { !it.paid }.sumOf { it.balance }
    val money = NumberFormat.getNumberInstance(Locale("tr", "TR")).apply { maximumFractionDigits = 2 }

    MaterialTheme(colorScheme = darkColorScheme(primary = Turquoise, background = Navy, surface = Panel)) {
        Scaffold(containerColor = Navy, topBar = {
            TopAppBar(
                title = { Column { Text("FINANSIM", fontWeight = FontWeight.Black, letterSpacing = 2.sp); Text("Kişisel borç kontrolü", color = Muted, fontSize = 11.sp) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Navy, titleContentColor = Color.White),
                actions = { IconButton(onClick = { showPrivacy = true }) { Icon(Icons.Default.Notifications, "Bildirim ayarları", tint = Turquoise) } }
            )
        }, floatingActionButton = {
            FloatingActionButton(onClick = { showAdd = true }, containerColor = Turquoise, contentColor = Navy) { Icon(Icons.Default.Add, "Borç ekle") }
        }) { padding ->
            LazyColumn(Modifier.padding(padding).fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(20.dp)) {
                            Text("TOPLAM AÇIK BORÇ", color = Muted, fontSize = 12.sp, letterSpacing = 1.sp)
                            Text("${money.format(total)} TL", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(10.dp))
                            Text("${debts.count { !it.paid }} açık kayıt  •  ${debts.count { it.paid }} ödenmiş", color = Turquoise, fontSize = 12.sp)
                        }
                    }
                }
                item { Text("Hesapların", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
                if (debts.isEmpty()) item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                        Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.AccountBalanceWallet, null, tint = Turquoise, modifier = Modifier.size(40.dp))
                            Text("Henüz kayıt yok", color = Color.White, fontWeight = FontWeight.Bold)
                            Text("Sağ alttaki + düğmesiyle kartını, avans hesabını veya kredini ekle.", color = Muted)
                        }
                    }
                }
                items(debts, key = { it.id }) { debt ->
                    DebtCard(debt, money.format(debt.balance), onPaid = {
                        persist(debts.map { if (it.id == debt.id) it.copy(paid = true) else it })
                    }, onDelete = { persist(debts.filterNot { it.id == debt.id }) })
                }
                item { Spacer(Modifier.height(70.dp)) }
            }
        }
        if (showAdd) AddDebtDialog(onDismiss = { showAdd = false }, onSave = {
            persist(debts + it); showAdd = false
        })
        if (showPrivacy) AlertDialog(
            onDismissRequest = { showPrivacy = false },
            title = { Text("Ödeme hatırlatmaları") },
            text = { Column {
                Text("Bildirim iznini aç. Bu ilk sürümde kayıtlı ödeme tarihleri uygulama içinde görünür; otomatik zamanlanmış hatırlatmalar henüz etkin değildir.")
                Spacer(Modifier.height(12.dp))
                Text("Hatırlatma tercihi: $reminderDays gün önce")
                Slider(value = reminderDays.toFloat(), onValueChange = { reminderDays = it.toInt() }, valueRange = 1f..7f, steps = 5)
            } },
            confirmButton = { TextButton(onClick = {
                prefs.edit().putInt("reminderDays", reminderDays).apply()
                if (Build.VERSION.SDK_INT >= 33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                    permission.launch(Manifest.permission.POST_NOTIFICATIONS)
                showPrivacy = false
            }) { Text("Kaydet") } },
            dismissButton = { TextButton(onClick = { showPrivacy = false }) { Text("Kapat") } }
        )
    }
}

@Composable
fun DebtCard(debt: Debt, amount: String, onPaid: () -> Unit, onDelete: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(if (debt.kind == "Kredi kartı") Icons.Default.CreditCard else Icons.Default.AccountBalanceWallet, null, tint = Turquoise)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(debt.name, color = Color.White, fontWeight = FontWeight.Bold)
                    Text(debt.kind, color = Muted, fontSize = 12.sp)
                }
                Text(if (debt.paid) "ÖDENDİ" else "AÇIK", color = if (debt.paid) Turquoise else Color(0xFFFFC36B), fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(12.dp))
            Text("$amount TL", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            if (debt.kind == "Kredi kartı") {
                Text("Limit: ${debt.limit.toLong()} TL  •  Ekstre: ${debt.statementDay}. gün  •  Son ödeme: ${debt.dueDay}. gün", color = Muted, fontSize = 11.sp)
            } else if (debt.limit > 0) Text("Limit: ${debt.limit.toLong()} TL", color = Muted, fontSize = 11.sp)
            if (debt.nextPayment.isNotBlank()) Text("Ödeme tarihi: ${debt.nextPayment}", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!debt.paid) Button(onClick = onPaid, colors = ButtonDefaults.buttonColors(containerColor = Turquoise, contentColor = Navy)) {
                    Icon(Icons.Default.CheckCircle, null); Spacer(Modifier.width(4.dp)); Text("Ödendi")
                }
                TextButton(onClick = onDelete) { Text("Sil", color = Color(0xFFFF8A80)) }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddDebtDialog(onDismiss: () -> Unit, onSave: (Debt) -> Unit) {
    var name by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf("Kredi kartı") }
    var balance by remember { mutableStateOf("") }
    var limit by remember { mutableStateOf("") }
    var statement by remember { mutableStateOf("") }
    var due by remember { mutableStateOf("") }
    var date by remember { mutableStateOf("") }
    val kinds = listOf("Kredi kartı", "Avans hesap / KMH", "İhtiyaç kredisi", "Diğer")
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Yeni hesap ekle") }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(name, { name = it }, label = { Text("Banka / hesap adı") }, singleLine = true)
            Text("Hesap türü", color = Muted)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                kinds.take(2).forEach { k -> FilterChip(selected = kind == k, onClick = { kind = k }, label = { Text(k, fontSize = 10.sp) }) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                kinds.drop(2).forEach { k -> FilterChip(selected = kind == k, onClick = { kind = k }, label = { Text(k, fontSize = 10.sp) }) }
            }
            OutlinedTextField(balance, { balance = it }, label = { Text("Güncel borç (TL)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            OutlinedTextField(limit, { limit = it }, label = { Text("Toplam limit (TL) - isteğe bağlı") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            if (kind == "Kredi kartı") {
                OutlinedTextField(statement, { statement = it }, label = { Text("Ekstre kesim günü (1-31)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                OutlinedTextField(due, { due = it }, label = { Text("Son ödeme günü (1-31)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            }
            OutlinedTextField(date, { date = it }, label = { Text("Sonraki ödeme tarihi (GG.AA.YYYY)") }, singleLine = true)
        }
    }, confirmButton = {
        TextButton(enabled = name.isNotBlank() && (balance.toDoubleOrNull() != null), onClick = {
            onSave(Debt(name = name.trim(), kind = kind, balance = balance.toDoubleOrNull() ?: 0.0,
                limit = limit.toDoubleOrNull() ?: 0.0, statementDay = statement.toIntOrNull() ?: 0,
                dueDay = due.toIntOrNull() ?: 0, nextPayment = date.trim()))
        }) { Text("Kaydet") }
    }, dismissButton = { TextButton(onClick = onDismiss) { Text("Vazgeç") } })
}

fun saveDebts(list: List<Debt>): String {
    val arr = JSONArray()
    list.forEach { d -> arr.put(JSONObject().apply {
        put("id", d.id); put("name", d.name); put("kind", d.kind); put("balance", d.balance)
        put("limit", d.limit); put("statementDay", d.statementDay); put("dueDay", d.dueDay)
        put("nextPayment", d.nextPayment); put("paid", d.paid)
    }) }
    return arr.toString()
}
fun loadDebts(raw: String): List<Debt> = try {
    val a = JSONArray(raw); (0 until a.length()).map { i ->
        val o = a.getJSONObject(i)
        Debt(o.optString("id"), o.optString("name"), o.optString("kind"), o.optDouble("balance"),
            o.optDouble("limit"), o.optInt("statementDay"), o.optInt("dueDay"), o.optString("nextPayment"), o.optBoolean("paid"))
    }
} catch (_: Exception) { emptyList() }
