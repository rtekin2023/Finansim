package com.finansim.app

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.net.Uri
import java.net.URL
import java.net.HttpURLConnection
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import java.security.SecureRandom
import android.view.WindowManager
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

private val Navy = Color(0xFF002C35)
val Panel = Color(0xFF06232D)
private val Panel2 = Color(0xFF064653)
val Aqua = Color(0xFF20E0D0)
private val Blue = Color(0xFF20E0D0)
val Muted = Color(0xFF9BB0C1)
val Red = Color(0xFFFF6474)
private val Green = Color(0xFF37D69A)

data class Debt(val id:String=UUID.randomUUID().toString(), val name:String, val kind:String, val balance:Double,
    val limit:Double=0.0, val statementDay:Int=0, val dueDay:Int=0, val nextPayment:String="", val paid:Boolean=false,
    val loanPrincipal:Double=0.0, val interestRate:Double=0.0, val interestPeriod:String="Aylık", val termMonths:Int=0,
    val installmentAmount:Double=0.0, val totalRepayment:Double=0.0, val remainingInstallments:Int=0,
    val earlyPayoffAmount:Double=0.0, val statementAmount:Double=0.0, val minimumPayment:Double=0.0)
data class Income(val id:String=UUID.randomUUID().toString(), val title:String, val amount:Double, val date:String, val note:String="")
data class Expense(val id:String=UUID.randomUUID().toString(), val title:String, val category:String, val amount:Double, val date:String, val note:String="")

class MainActivity:ComponentActivity(){
 override fun onStop(){ super.onStop(); getSharedPreferences("finansim_lock",Context.MODE_PRIVATE).edit().putLong("background_at",System.currentTimeMillis()).apply() }
 override fun onStart(){ super.onStart(); val p=getSharedPreferences("finansim_lock",Context.MODE_PRIVATE); val t=p.getLong("background_at",0L); if(t>0L && System.currentTimeMillis()-t>=5*60*1000L){p.edit().remove("background_at").apply(); recreate()} else if(t>0L){p.edit().remove("background_at").apply()} }
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState); window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE); createChannel(); ReminderScheduler.rescheduleAll(this); setContent { FinansimApp(this) }}
 private fun createChannel(){ getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("finansim_payments","Finansım ödeme hatırlatmaları",NotificationManager.IMPORTANCE_HIGH).apply{description="Ekstre ve ödeme tarihi hatırlatmaları"}) }
}

object ReminderScheduler {
 fun schedule(context:Context, debt:Debt, daysBefore:Int){
   if(debt.nextPayment.isBlank()) return
   try {
    val sdf=SimpleDateFormat("dd.MM.yyyy",Locale("tr","TR")); sdf.isLenient=false
    val due=sdf.parse(debt.nextPayment) ?: return
    val fire=Calendar.getInstance().apply { time=due; add(Calendar.DAY_OF_YEAR,-daysBefore); set(Calendar.HOUR_OF_DAY,9); set(Calendar.MINUTE,0); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0) }
    if(fire.timeInMillis<=System.currentTimeMillis()) return
    val intent=Intent(context,ReminderReceiver::class.java).putExtra("title", "${debt.name} ödeme hatırlatması").putExtra("body", "${debt.nextPayment} tarihinde ${debt.balance.toLong()} TL ödeme görünüyor.")
    val pi=PendingIntent.getBroadcast(context,debt.id.hashCode(),intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    val alarm=context.getSystemService(AlarmManager::class.java)
    alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,fire.timeInMillis,pi)
   }catch (_:Exception){}
 }
 fun rescheduleAll(context:Context){
   val p=context.getSharedPreferences("finansim",Context.MODE_PRIVATE)
   val ds=loadDebts(p.getString("debts","[]")?:"[]")
   val days=p.getInt("reminderDays",1)
   ds.filter{!it.paid}.forEach{schedule(context,it,days)}
 }
}
class ReminderReceiver:BroadcastReceiver(){
 override fun onReceive(context:Context,intent:Intent){
  if(Build.VERSION.SDK_INT>=33 && context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return
  val n=androidx.core.app.NotificationCompat.Builder(context,"finansim_payments").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(intent.getStringExtra("title")?:"Finansım hatırlatma").setContentText(intent.getStringExtra("body")?:"Yaklaşan ödemen var.").setStyle(androidx.core.app.NotificationCompat.BigTextStyle().bigText(intent.getStringExtra("body")?:"Yaklaşan ödemen var.")).setPriority(androidx.core.app.NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).build()
  context.getSystemService(NotificationManager::class.java).notify((System.currentTimeMillis()%100000).toInt(),n)
 }
}
class BootReceiver:BroadcastReceiver(){ override fun onReceive(context:Context,intent:Intent){ if(intent.action==Intent.ACTION_BOOT_COMPLETED) ReminderScheduler.rescheduleAll(context) } }

@Composable fun FinansimApp(context:Context){
    var unlocked by remember { mutableStateOf(false) }
    val prefs = remember { secureFinansimPrefs(context) }
    val hasPin = remember { !prefs.getString("pinHash", null).isNullOrBlank() }
    if (!unlocked) {
        PinGate(context, prefs, hasPin) { unlocked = true }
    } else {
        FinansimUnlockedApp(context)
    }
}

private fun secureFinansimPrefs(context: Context): android.content.SharedPreferences {
    val masterKey = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
    val encrypted = EncryptedSharedPreferences.create(
        context, "finansim_secure", masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
    val legacy = context.getSharedPreferences("finansim", Context.MODE_PRIVATE)
    if (encrypted.all.isEmpty() && legacy.all.isNotEmpty()) {
        val editor = encrypted.edit()
        legacy.all.forEach { (k, v) -> when(v) {
            is String -> editor.putString(k, v)
            is Int -> editor.putInt(k, v)
            is Float -> editor.putFloat(k, v)
            is Long -> editor.putLong(k, v)
            is Boolean -> editor.putBoolean(k, v)
        } }
        editor.apply()
        legacy.edit().clear().apply()
    }
    return encrypted
}

private fun pinHash(pin: String, salt: ByteArray): String {
    val spec = PBEKeySpec(pin.toCharArray(), salt, 150000, 256)
    val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    spec.clearPassword()
    return android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
}

@Composable private fun PinGate(context: Context, prefs: android.content.SharedPreferences, hasPin: Boolean, onUnlock: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var message by remember { mutableStateOf(if (hasPin) "Finansım'a hoş geldin" else "Finansım için PIN oluştur") }
    var attempts by remember { mutableIntStateOf(0) }
    var setup by remember { mutableStateOf(!hasPin) }
    var generatedRecovery by remember { mutableStateOf("") }
    var recoveryDialog by remember { mutableStateOf(false) }
    var recoveryMode by remember { mutableStateOf(false) }
    var recoveryInput by remember { mutableStateOf("") }
    var replacementPin by remember { mutableStateOf("") }
    var recoveryMessage by remember { mutableStateOf("") }
    MaterialTheme(colorScheme = darkColorScheme(primary=Aqua, background=Navy, surface=Panel, onSurface=Color.White)) {
        Box(Modifier.fillMaxSize().background(
            androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color(0xFF087F83), Navy, Color(0xFF001A25)))
        ).padding(24.dp), contentAlignment=Alignment.Center) {
            Column(horizontalAlignment=Alignment.CenterHorizontally, verticalArrangement=Arrangement.spacedBy(16.dp)) {
                Box(Modifier.size(82.dp).background(Panel2, RoundedCornerShape(26.dp)), contentAlignment=Alignment.Center) {
                    Icon(Icons.Default.AccountBalanceWallet, null, tint=Aqua, modifier=Modifier.size(42.dp))
                }
                Text("FİNANSIM", color=Color.White, fontSize=26.sp, fontWeight=FontWeight.Black, letterSpacing=2.sp)
                Text(message, color=Muted, fontSize=14.sp)
                OutlinedTextField(value=pin, onValueChange={ if(it.length<=6 && it.all(Char::isDigit)) pin=it },
                    label={Text("6 haneli PIN")}, singleLine=true, visualTransformation=PasswordVisualTransformation(),
                    keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword))
                if(setup) OutlinedTextField(value=confirm, onValueChange={if(it.length<=6 && it.all(Char::isDigit))confirm=it},
                    label={Text("PIN'i tekrar gir")}, singleLine=true, visualTransformation=PasswordVisualTransformation(),
                    keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword))
                Button(onClick={
                    if(pin.length!=6) message="PIN 6 rakamdan oluşmalı"
                    else if(setup && pin!=confirm) message="PIN'ler eşleşmiyor"
                    else if(setup) {
                        val salt=ByteArray(16).also{SecureRandom().nextBytes(it)}
                        val recovery=ByteArray(8).also{SecureRandom().nextBytes(it)}.joinToString(""){"%02X".format(it)}
                        val recoverySalt=ByteArray(16).also{SecureRandom().nextBytes(it)}
                        prefs.edit().putString("pinSalt",android.util.Base64.encodeToString(salt,android.util.Base64.NO_WRAP))
                            .putString("pinHash",pinHash(pin,salt))
                            .putString("recoverySalt",android.util.Base64.encodeToString(recoverySalt,android.util.Base64.NO_WRAP))
                            .putString("recoveryHash",pinHash(recovery,recoverySalt)).apply()
                        generatedRecovery=recovery
                        recoveryDialog=true
                    } else {
                        val salt=android.util.Base64.decode(prefs.getString("pinSalt",""),android.util.Base64.DEFAULT)
                        if(pinHash(pin,salt)==prefs.getString("pinHash","")) onUnlock()
                        else { attempts++; message=if(attempts>=5) "Çok fazla hatalı deneme. Biraz bekleyip tekrar dene." else "PIN hatalı. Tekrar dene."; pin="" }
                    }
                }, modifier=Modifier.fillMaxWidth(), colors=ButtonDefaults.buttonColors(containerColor=Aqua,contentColor=Navy)) {
                    Text(if(setup) "Güvenli PIN oluştur" else "Kilidi aç", fontWeight=FontWeight.Bold)
                }
                if(!setup) TextButton(onClick={recoveryMode=true;recoveryMessage="Kurtarma kodunu ve yeni PIN'ini gir."}) { Text("PIN'imi kurtar",color=Aqua) }
                Text("Verilerin cihazında şifreli saklanır", color=Muted, fontSize=11.sp)
            }
        }
    }
    if(recoveryDialog) AlertDialog(onDismissRequest={},title={Text("PIN kurtarma kodun")},text={Text("$generatedRecovery\n\nBu kodu güvenli bir yere kaydet. Bu kod tekrar gösterilemez.")},confirmButton={TextButton(onClick={recoveryDialog=false;onUnlock()}){Text("Kaydettim")}})
    if(recoveryMode) AlertDialog(onDismissRequest={recoveryMode=false},title={Text("PIN kurtarma")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Text(recoveryMessage,color=Muted);OutlinedTextField(recoveryInput,{recoveryInput=it.uppercase(Locale.ROOT)},label={Text("Kurtarma kodu")});OutlinedTextField(replacementPin,{if(it.length<=6&&it.all(Char::isDigit))replacementPin=it},label={Text("Yeni 6 haneli PIN")},visualTransformation=PasswordVisualTransformation(),keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.NumberPassword))}},confirmButton={TextButton(onClick={val salt=android.util.Base64.decode(prefs.getString("recoverySalt","")?:"",android.util.Base64.DEFAULT);val expected=prefs.getString("recoveryHash","");if(salt.isNotEmpty()&&replacementPin.length==6&&pinHash(recoveryInput,salt)==expected){val newSalt=ByteArray(16).also{SecureRandom().nextBytes(it)};prefs.edit().putString("pinSalt",android.util.Base64.encodeToString(newSalt,android.util.Base64.NO_WRAP)).putString("pinHash",pinHash(replacementPin,newSalt)).remove("recoveryHash").remove("recoverySalt").apply();recoveryMode=false;onUnlock()}else recoveryMessage="Kod yanlış veya yeni PIN 6 haneli değil."}){Text("PIN'i yenile")}},dismissButton={TextButton(onClick={recoveryMode=false}){Text("Vazgeç")}})
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun FinansimUnlockedApp(context:Context){
 val prefs=remember{secureFinansimPrefs(context)}
 var debts by remember{mutableStateOf(loadDebts(prefs.getString("debts","[]")?:"[]"))}
 var incomes by remember{mutableStateOf(loadIncomes(prefs.getString("incomes","[]")?:"[]"))}
 var expenses by remember{mutableStateOf(loadExpenses(prefs.getString("expenses","[]")?:"[]"))}
 var monthlyBudget by remember{mutableDoubleStateOf(prefs.getFloat("monthlyBudget",0f).toDouble())}
 var addExpense by remember{mutableStateOf(false)}
 var showBudget by remember{mutableStateOf(false)}
 var tab by remember{mutableIntStateOf(0)}
 var addDebt by remember{mutableStateOf(false)}; var addIncome by remember{mutableStateOf(false)}; var settings by remember{mutableStateOf(false)}
 var reminderDays by remember{mutableIntStateOf(prefs.getInt("reminderDays",1))}
 val coroutineScope=rememberCoroutineScope()
 fun saveDebtsNow(list:List<Debt>){debts=list;prefs.edit().putString("debts",encodeDebts(list)).apply(); list.filter{!it.paid}.forEach{ReminderScheduler.schedule(context,it,reminderDays)}}
 fun saveIncomesNow(list:List<Income>){incomes=list;prefs.edit().putString("incomes",encodeIncomes(list)).apply()}
 fun saveExpensesNow(list:List<Expense>){expenses=list;prefs.edit().putString("expenses",encodeExpenses(list)).apply()}
 val permission=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){}
 val exportCsv=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")){uri-> if(uri!=null) writeCsv(context,uri,incomes,expenses) }
 val importCsv=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri-> if(uri!=null) readExpenseCsv(context,uri)?.let{saveExpensesNow(expenses+it)} }
 val expenseTotal=expenses.sumOf{it.amount}
 val monthKey=SimpleDateFormat("MM.yyyy",Locale("tr","TR")).format(Date())
 val thisMonthIncome=incomes.filter{it.date.endsWith(monthKey)}.sumOf{it.amount}
 val thisMonthExpense=expenses.filter{it.date.endsWith(monthKey)}.sumOf{it.amount}
 val money=remember{NumberFormat.getNumberInstance(Locale("tr","TR")).apply{maximumFractionDigits=0}}
 val openDebt=debts.filter{!it.paid}.sumOf{it.balance}; val totalLimit=debts.sumOf{it.limit}; val usedLimit=debts.filter{it.limit>0}.sumOf{it.balance.coerceAtMost(it.limit)}
 val incomeTotal=incomes.sumOf{it.amount}; val usage=if(totalLimit>0)(usedLimit/totalLimit*100).toInt() else 0
 MaterialTheme(colorScheme=darkColorScheme(primary=Aqua,background=Navy,surface=Panel,onSurface=Color.White)){
  Scaffold(containerColor=Color(0xFF003B43), topBar={TopAppBar(title={Row(verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(38.dp).background(Panel2,RoundedCornerShape(12.dp)),contentAlignment=Alignment.Center){Icon(Icons.Default.AccountBalanceWallet,null,tint=Aqua)}; Spacer(Modifier.width(10.dp));Column{Text("Finansım",fontWeight=FontWeight.ExtraBold,fontSize=21.sp);Text("Tüm hesapların, tek yerde",fontSize=11.sp,color=Muted)}}},actions={IconButton(onClick={settings=true}){Icon(Icons.Default.NotificationsActive,null,tint=Aqua)}},colors=TopAppBarDefaults.topAppBarColors(containerColor=Navy,titleContentColor=Color.White))},
   floatingActionButton={FloatingActionButton(onClick={when(tab){1->addIncome=true;2->addExpense=true;else->addDebt=true}},containerColor=Aqua,contentColor=Navy){Icon(Icons.Default.Add,null)}},
   bottomBar={NavigationBar(containerColor=Panel){NavigationBarItem(selected=tab==0,onClick={tab=0},icon={Icon(Icons.Default.Home,null)},label={Text("Ana Sayfa")});NavigationBarItem(selected=tab==1,onClick={tab=1},icon={Icon(Icons.Default.TrendingUp,null)},label={Text("Gelir")});NavigationBarItem(selected=tab==2,onClick={tab=2},icon={Icon(Icons.Default.ReceiptLong,null)},label={Text("Gider")});NavigationBarItem(selected=tab==3,onClick={tab=3},icon={Icon(Icons.Default.CreditCard,null)},label={Text("Borçlar")});NavigationBarItem(selected=tab==4,onClick={tab=4},icon={Icon(Icons.Default.ShowChart,null)},label={Text("Piyasalar")});NavigationBarItem(selected=tab==5,onClick={tab=5},icon={Icon(Icons.Default.Tune,null)},label={Text("Araçlar")})}}){pad->
    when(tab){
     0->LazyColumn(Modifier.padding(pad).fillMaxSize().padding(horizontal=16.dp),verticalArrangement=Arrangement.spacedBy(13.dp),contentPadding=PaddingValues(top=8.dp,bottom=90.dp)){
       item{Card(colors=CardDefaults.cardColors(containerColor=Panel2),shape=RoundedCornerShape(24.dp)){Column(Modifier.fillMaxWidth().padding(20.dp)){Text("GENEL FİNANS DURUMUM",color=Muted,fontSize=11.sp,letterSpacing=1.sp);Spacer(Modifier.height(10.dp));Text("${money.format(openDebt)} TL",fontSize=30.sp,fontWeight=FontWeight.Black,color=Color.White);Text("Toplam açık borç",color=Muted,fontSize=12.sp);Spacer(Modifier.height(16.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Metric("Toplam limit","${money.format(totalLimit)} TL");Metric("Kullanılan","${money.format(usedLimit)} TL");Metric("Kullanım","%$usage")};Spacer(Modifier.height(12.dp));LinearProgressIndicator(progress={ (usage/100f).coerceIn(0f,1f)},modifier=Modifier.fillMaxWidth().height(8.dp),color=Aqua,trackColor=Panel)}}}
       item{Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){QuickTile("Gelir ekle",Icons.Default.Add,Aqua,Modifier.weight(1f)){addIncome=true};QuickTile("Hesap ekle",Icons.Default.CreditCard,Blue,Modifier.weight(1f)){addDebt=true};QuickTile("Bildirimler",Icons.Default.NotificationsActive,Green,Modifier.weight(1f)){settings=true}}}
       item{SectionTitle("Bu ayın özeti")}
       item{Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){SummaryCard("Bu ay gelir",thisMonthIncome,Green,Modifier.weight(1f));SummaryCard("Bu ay gider",thisMonthExpense,Red,Modifier.weight(1f))}}
       item{Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(18.dp)){Column(Modifier.fillMaxWidth().padding(16.dp)){Row(verticalAlignment=Alignment.CenterVertically){Text("Aylık bütçe",color=Color.White,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));TextButton(onClick={showBudget=true}){Text("Düzenle")}};Text(if(monthlyBudget>0)"${money.format(monthlyBudget-thisMonthExpense)} TL kaldı" else "Bütçe belirlenmedi",color=Aqua,fontSize=20.sp,fontWeight=FontWeight.Bold);if(monthlyBudget>0)LinearProgressIndicator(progress={(thisMonthExpense/monthlyBudget).toFloat().coerceIn(0f,1f)},modifier=Modifier.fillMaxWidth().padding(top=8.dp),color=if(thisMonthExpense>monthlyBudget)Red else Aqua,trackColor=Panel2)}}}
       item{SectionTitle("Yaklaşan ödemeler")}
       val upcoming=debts.filter{!it.paid && it.nextPayment.isNotBlank()}.sortedBy{it.nextPayment}
       if(upcoming.isEmpty())item{InfoCard("Henüz ödeme tarihi eklenmedi","Bir hesaba ödeme tarihi eklediğinde burada görünecek.")}
       items(upcoming.take(5),key={"up"+it.id}){d->PaymentRow(d, money.format(d.balance))}
       item{SectionTitle("Hesapların")}
       if(debts.isEmpty())item{InfoCard("Henüz hesap eklemedin","Kredi kartını, avans hesabını veya kredini + düğmesiyle ekleyebilirsin.")}
       items(debts.take(6),key={it.id}){d->DebtRow(d,money.format(d.balance),onPaid={saveDebtsNow(debts.map{if(it.id==d.id)it.copy(paid=true)else it})},onDelete={saveDebtsNow(debts.filterNot{it.id==d.id})})}
     }
     1->LazyColumn(Modifier.padding(pad).fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp),contentPadding=PaddingValues(bottom=90.dp)){item{Text("Gelirlerim",fontSize=24.sp,fontWeight=FontWeight.Bold)};item{SummaryCard("Kayıtlı toplam gelir",incomeTotal,Green,Modifier.fillMaxWidth())};if(incomes.isEmpty())item{InfoCard("Henüz gelir yok","Maaşını, primini veya ek gelirini + düğmesiyle kaydet.")};items(incomes,key={it.id}){inc->Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(18.dp)){Row(Modifier.fillMaxWidth().padding(16.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(inc.title,color=Color.White,fontWeight=FontWeight.Bold);Text("${inc.date}  ${inc.note}",color=Muted,fontSize=12.sp)};Text("+${money.format(inc.amount)} TL",color=Green,fontWeight=FontWeight.Bold);IconButton(onClick={saveIncomesNow(incomes.filterNot{it.id==inc.id})}){Icon(Icons.Default.Delete,null,tint=Red)}}}}}
     2->LazyColumn(Modifier.padding(pad).fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp),contentPadding=PaddingValues(bottom=90.dp)){item{Text("Harcamalarım",fontSize=24.sp,fontWeight=FontWeight.Bold)};item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick={importCsv.launch(arrayOf("text/*","application/csv","application/vnd.ms-excel"))}){Text("CSV içe aktar")};OutlinedButton(onClick={exportCsv.launch("Finansim-ekstre.csv")}){Text("CSV dışa aktar")}}};item{MonthlyChart(incomes,expenses)};item{Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){SummaryCard("Toplam gider",expenseTotal,Red,Modifier.weight(1f));SummaryCard("Bu ay",thisMonthExpense,Red,Modifier.weight(1f))}};item{InfoCard("Gider kategorileri","Market, yakıt, fatura, yemek ve diğer harcamalarını kaydet. Kayıtlar cihazında saklanır.")};if(expenses.isEmpty())item{InfoCard("Henüz gider yok","Sağ alttaki + düğmesiyle ilk harcamanı ekle.")};items(expenses.sortedByDescending{it.date},key={it.id}){e->Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(16.dp)){Row(Modifier.fillMaxWidth().padding(14.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(e.title,color=Color.White,fontWeight=FontWeight.Bold);Text("${e.category} • ${e.date}",color=Muted,fontSize=12.sp)};Text("-${money.format(e.amount)} TL",color=Red,fontWeight=FontWeight.Bold);IconButton(onClick={saveExpensesNow(expenses.filterNot{it.id==e.id})}){Icon(Icons.Default.Delete,null,tint=Red)}}}}}
     3->LazyColumn(Modifier.padding(pad).fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp),contentPadding=PaddingValues(bottom=90.dp)){item{Text("Kartlarım ve borçlarım",fontSize=24.sp,fontWeight=FontWeight.Bold)};item{InfoCard("Limit ve ekstre takibi","Kredi kartlarında limit, kullanılan tutar, ekstre kesim ve son ödeme gününü kaydedebilirsin. Avans hesaplarını da ayrı takip edebilirsin.")};if(debts.isEmpty())item{InfoCard("Henüz hesap yok","Sağ alttaki + düğmesine basarak hesap ekle.")};items(debts,key={it.id}){d->DebtRow(d,money.format(d.balance),onPaid={saveDebtsNow(debts.map{if(it.id==d.id)it.copy(paid=true)else it})},onDelete={saveDebtsNow(debts.filterNot{it.id==d.id})})}}
     4->MarketsScreen(Modifier.padding(pad),coroutineScope)
     5->AdvancedFinanceScreen(context,prefs)
    }
   }
  }
  if(addDebt)AddDebtDialog({addDebt=false}){d->saveDebtsNow(debts+d);addDebt=false}
  if(addIncome)AddIncomeDialog({addIncome=false}){i->saveIncomesNow(incomes+i);addIncome=false}
  if(addExpense)AddExpenseDialog({addExpense=false}){e->saveExpensesNow(expenses+e);addExpense=false}
  if(showBudget)BudgetDialog(monthlyBudget,{showBudget=false}){v->monthlyBudget=v;prefs.edit().putFloat("monthlyBudget",v.toFloat()).apply();showBudget=false}
  if(settings)AlertDialog(onDismissRequest={settings=false},title={Text("Bildirim ayarları")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Text("Ödeme tarihinden kaç gün önce hatırlatayım?",color=Muted);Text("$reminderDays gün önce",color=Aqua,fontWeight=FontWeight.Bold);Slider(value=reminderDays.toFloat(),onValueChange={reminderDays=it.toInt().coerceIn(0,7)},valueRange=0f..7f,steps=6);Text("Bildirimler saat 09.00 için planlanır. Android pil tasarrufu bildirim saatini geciktirebilir.",fontSize=12.sp,color=Muted)}},confirmButton={TextButton(onClick={prefs.edit().putInt("reminderDays",reminderDays).apply();ReminderScheduler.rescheduleAll(context);if(Build.VERSION.SDK_INT>=33&&context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)permission.launch(Manifest.permission.POST_NOTIFICATIONS);settings=false}){Text("Kaydet")}},dismissButton={TextButton(onClick={settings=false}){Text("Kapat")}})
 }

@Composable fun Metric(label:String,value:String){Column{Text(label,color=Muted,fontSize=10.sp);Text(value,color=Color.White,fontSize=12.sp,fontWeight=FontWeight.Bold)}}
@Composable fun SectionTitle(t:String){Text(t,color=Color.White,fontSize=18.sp,fontWeight=FontWeight.Bold)}
@Composable fun SummaryCard(title:String,value:Double,color:Color,modifier:Modifier){Card(modifier,colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(16.dp)){Text(title,color=Muted,fontSize=12.sp);Text("${NumberFormat.getNumberInstance(Locale("tr","TR")).format(value)} TL",color=color,fontSize=19.sp,fontWeight=FontWeight.Bold)}}}
@Composable fun QuickTile(title:String,icon:androidx.compose.ui.graphics.vector.ImageVector,color:Color,modifier:Modifier,onClick:()->Unit){Card(modifier.clickable(onClick=onClick),colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(16.dp)){Column(Modifier.fillMaxWidth().padding(vertical=14.dp),horizontalAlignment=Alignment.CenterHorizontally){Icon(icon,null,tint=color);Spacer(Modifier.height(5.dp));Text(title,color=Color.White,fontSize=11.sp,fontWeight=FontWeight.SemiBold)}}}
@Composable fun InfoCard(title:String,body:String){Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(18.dp)){Text(title,color=Color.White,fontWeight=FontWeight.Bold);Text(body,color=Muted,fontSize=12.sp)}}}
@Composable fun PaymentRow(d:Debt,amount:String){Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(16.dp)){Row(Modifier.fillMaxWidth().padding(14.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.Event,null,tint=Aqua);Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(d.name,color=Color.White,fontWeight=FontWeight.Bold);Text("Ödeme: ${d.nextPayment}",color=Muted,fontSize=12.sp)};Text("$amount TL",color=Color.White,fontWeight=FontWeight.Bold)}}}
@Composable fun DebtRow(d:Debt,amount:String,onPaid:()->Unit,onDelete:()->Unit){Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(15.dp)){Row(verticalAlignment=Alignment.CenterVertically){Icon(if(d.kind=="Kredi kartı")Icons.Default.CreditCard else Icons.Default.AccountBalanceWallet,null,tint=Aqua);Spacer(Modifier.width(9.dp));Column(Modifier.weight(1f)){Text(d.name,color=Color.White,fontWeight=FontWeight.Bold);Text(d.kind,color=Muted,fontSize=11.sp)};Text(if(d.paid)"ÖDENDİ" else "AÇIK",color=if(d.paid)Green else Aqua,fontSize=10.sp,fontWeight=FontWeight.Bold)};Spacer(Modifier.height(8.dp));Text("$amount TL",color=Color.White,fontSize=21.sp,fontWeight=FontWeight.Bold);if(d.limit>0)Text("Limit: ${d.limit.toLong()} TL  •  Kullanılabilir: ${(d.limit-d.balance).coerceAtLeast(0.0).toLong()} TL",color=Muted,fontSize=11.sp);if(d.kind=="Kredi kartı"){Text("Ekstre kesim: ${d.statementDay}. gün  •  Son ödeme: ${d.dueDay}. gün",color=Muted,fontSize=11.sp);if(d.statementAmount>0)Text("Dönem ekstresi: ${d.statementAmount.toLong()} TL  •  Asgari: ${d.minimumPayment.toLong()} TL",color=Aqua,fontSize=12.sp)};if(d.kind.contains("kredi",true)){Text("Kredi tutarı: ${d.loanPrincipal.toLong()} TL  •  Faiz: %${d.interestRate} ${d.interestPeriod.lowercase(Locale("tr","TR"))}",color=Muted,fontSize=11.sp);Text("Vade: ${d.termMonths} ay  •  Kalan taksit: ${d.remainingInstallments}",color=Muted,fontSize=11.sp);Text("Aylık taksit: ${d.installmentAmount.toLong()} TL  •  Toplam geri ödeme: ${d.totalRepayment.toLong()} TL",color=Aqua,fontSize=12.sp);if(d.earlyPayoffAmount>0)Text("Erken kapama: ${d.earlyPayoffAmount.toLong()} TL",color=Muted,fontSize=11.sp)};if(d.nextPayment.isNotBlank())Text("Sonraki ödeme: ${d.nextPayment}",color=Muted,fontSize=11.sp);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){if(!d.paid)Button(onClick=onPaid,colors=ButtonDefaults.buttonColors(containerColor=Aqua,contentColor=Navy)){Icon(Icons.Default.Check,null);Text("Ödendi")};TextButton(onClick=onDelete){Text("Sil",color=Red)}}}}}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun AddDebtDialog(onDismiss:()->Unit,onSave:(Debt)->Unit){
 var name by remember{mutableStateOf("")};var kind by remember{mutableStateOf("Kredi kartı")};var balance by remember{mutableStateOf("")};var limit by remember{mutableStateOf("")};var statement by remember{mutableStateOf("")};var due by remember{mutableStateOf("")};var date by remember{mutableStateOf("")}
 var principal by remember{mutableStateOf("")};var rate by remember{mutableStateOf("")};var ratePeriod by remember{mutableStateOf("Aylık")};var term by remember{mutableStateOf("")};var installment by remember{mutableStateOf("")};var total by remember{mutableStateOf("")};var remaining by remember{mutableStateOf("")};var early by remember{mutableStateOf("")};var statementAmount by remember{mutableStateOf("")};var minimum by remember{mutableStateOf("")}
 val kinds=listOf("Kredi kartı","Avans hesap / KMH","İhtiyaç kredisi","Taşıt kredisi","Konut kredisi","Diğer")
 fun num(v:String)=v.replace(",",".").toDoubleOrNull()?:0.0
 AlertDialog(onDismissRequest=onDismiss,title={Text("Borç / hesap ekle")},text={Column(Modifier.heightIn(max=560.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(7.dp)){
  OutlinedTextField(name,{name=it},label={Text("Banka / hesap adı")},singleLine=true);Text("Hesap türü",color=Muted);kinds.chunked(2).forEach{row->Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){row.forEach{k->FilterChip(selected=kind==k,onClick={kind=k},label={Text(k,fontSize=10.sp)})}}}
  OutlinedTextField(balance,{balance=it},label={Text("Güncel kalan borç (TL)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),singleLine=true)
  if(kind=="Kredi kartı"){
   OutlinedTextField(limit,{limit=it},label={Text("Kart limiti (TL)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),singleLine=true)
   OutlinedTextField(statement,{statement=it},label={Text("Ekstre kesim günü (1-31)")},singleLine=true)
   OutlinedTextField(due,{due=it},label={Text("Son ödeme günü (1-31)")},singleLine=true)
   OutlinedTextField(statementAmount,{statementAmount=it},label={Text("Güncel ekstre borcu (TL)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),singleLine=true)
   OutlinedTextField(minimum,{minimum=it},label={Text("Asgari ödeme tutarı (TL)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),singleLine=true)
  }
  if(kind.contains("kredi",true)){
   Text("Kredi geri ödeme bilgileri",color=Aqua,fontWeight=FontWeight.Bold)
   OutlinedTextField(principal,{principal=it},label={Text("Kullanılan kredi / anapara (TL)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),singleLine=true)
   OutlinedTextField(rate,{rate=it},label={Text("Faiz oranı (%)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),singleLine=true)
   Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){FilterChip(selected=ratePeriod=="Aylık",onClick={ratePeriod="Aylık"},label={Text("Aylık faiz")});FilterChip(selected=ratePeriod=="Yıllık",onClick={ratePeriod="Yıllık"},label={Text("Yıllık faiz")})}
   OutlinedTextField(term,{term=it},label={Text("Toplam vade (ay)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),singleLine=true)
   OutlinedTextField(installment,{installment=it},label={Text("Aylık taksit tutarı (TL)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),singleLine=true)
   OutlinedTextField(total,{total=it},label={Text("Toplam geri ödeme (TL)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),singleLine=true)
   OutlinedTextField(remaining,{remaining=it},label={Text("Kalan taksit sayısı")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Number),singleLine=true)
   OutlinedTextField(early,{early=it},label={Text("Bugünkü erken kapama tutarı (TL)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),singleLine=true)
  }
  OutlinedTextField(date,{date=it},label={Text("Sonraki ödeme tarihi (GG.AA.YYYY)")},singleLine=true)
  Text("Faiz ve taksit bilgileri bankanın ödeme planından girilmelidir. Uygulama bunları takip eder; banka kapama tutarını kendisi hesaplamaz.",color=Muted,fontSize=11.sp)
 }},confirmButton={TextButton(enabled=name.isNotBlank()&&balance.toDoubleOrNull()!=null,onClick={onSave(Debt(name=name,kind=kind,balance=num(balance),limit=num(limit),statementDay=statement.toIntOrNull()?:0,dueDay=due.toIntOrNull()?:0,nextPayment=date.trim(),loanPrincipal=num(principal),interestRate=num(rate),interestPeriod=ratePeriod,termMonths=term.toIntOrNull()?:0,installmentAmount=num(installment),totalRepayment=num(total),remainingInstallments=remaining.toIntOrNull()?:0,earlyPayoffAmount=num(early),statementAmount=num(statementAmount),minimumPayment=num(minimum)))}){Text("Kaydet")}},dismissButton={TextButton(onClick=onDismiss){Text("Vazgeç")}})
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun AddIncomeDialog(onDismiss:()->Unit,onSave:(Income)->Unit){var title by remember{mutableStateOf("Maaş")};var amount by remember{mutableStateOf("")};var date by remember{mutableStateOf(SimpleDateFormat("dd.MM.yyyy",Locale("tr","TR")).format(Date()))};var note by remember{mutableStateOf("")};AlertDialog(onDismissRequest=onDismiss,title={Text("Gelir ekle")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(title,{title=it},label={Text("Gelir adı (maaş, prim, ek gelir)")},singleLine=true);OutlinedTextField(amount,{amount=it},label={Text("Tutar (TL)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),singleLine=true);OutlinedTextField(date,{date=it},label={Text("Tarih (GG.AA.YYYY)")},singleLine=true);OutlinedTextField(note,{note=it},label={Text("Not (isteğe bağlı)")},singleLine=true)}},confirmButton={TextButton(enabled=title.isNotBlank()&&amount.toDoubleOrNull()!=null,onClick={onSave(Income(title=title,amount=amount.toDoubleOrNull()?:0.0,date=date,note=note))}){Text("Kaydet")}},dismissButton={TextButton(onClick=onDismiss){Text("Vazgeç")}})}

fun encodeDebts(list:List<Debt>)=JSONArray().apply{list.forEach{d->put(JSONObject().apply{put("id",d.id);put("name",d.name);put("kind",d.kind);put("balance",d.balance);put("limit",d.limit);put("statementDay",d.statementDay);put("dueDay",d.dueDay);put("nextPayment",d.nextPayment);put("paid",d.paid);put("loanPrincipal",d.loanPrincipal);put("interestRate",d.interestRate);put("interestPeriod",d.interestPeriod);put("termMonths",d.termMonths);put("installmentAmount",d.installmentAmount);put("totalRepayment",d.totalRepayment);put("remainingInstallments",d.remainingInstallments);put("earlyPayoffAmount",d.earlyPayoffAmount);put("statementAmount",d.statementAmount);put("minimumPayment",d.minimumPayment)})}}.toString()
fun loadDebts(raw:String):List<Debt> = try{val a=JSONArray(raw);(0 until a.length()).map{val o=a.getJSONObject(it);Debt(id=o.optString("id"),name=o.optString("name"),kind=o.optString("kind"),balance=o.optDouble("balance"),limit=o.optDouble("limit"),statementDay=o.optInt("statementDay"),dueDay=o.optInt("dueDay"),nextPayment=o.optString("nextPayment"),paid=o.optBoolean("paid"),loanPrincipal=o.optDouble("loanPrincipal"),interestRate=o.optDouble("interestRate"),interestPeriod=o.optString("interestPeriod","Aylık"),termMonths=o.optInt("termMonths"),installmentAmount=o.optDouble("installmentAmount"),totalRepayment=o.optDouble("totalRepayment"),remainingInstallments=o.optInt("remainingInstallments"),earlyPayoffAmount=o.optDouble("earlyPayoffAmount"),statementAmount=o.optDouble("statementAmount"),minimumPayment=o.optDouble("minimumPayment"))}}catch(_:Exception){emptyList()}
fun encodeIncomes(list:List<Income>)=JSONArray().apply{list.forEach{i->put(JSONObject().apply{put("id",i.id);put("title",i.title);put("amount",i.amount);put("date",i.date);put("note",i.note)})}}.toString()
fun loadIncomes(raw:String):List<Income> = try{val a=JSONArray(raw);(0 until a.length()).map{val o=a.getJSONObject(it);Income(o.optString("id"),o.optString("title"),o.optDouble("amount"),o.optString("date"),o.optString("note"))}}catch(_:Exception){emptyList()}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun AddExpenseDialog(onDismiss:()->Unit,onSave:(Expense)->Unit){
 var title by remember{mutableStateOf("")};var category by remember{mutableStateOf("Market")};var amount by remember{mutableStateOf("")};var date by remember{mutableStateOf(SimpleDateFormat("dd.MM.yyyy",Locale("tr","TR")).format(Date()))};var note by remember{mutableStateOf("")}
 val cats=listOf("Market","Yakıt","Fatura","Yemek","Ulaşım","Sağlık","Alışveriş","Eğlence","Diğer")
 AlertDialog(onDismissRequest=onDismiss,title={Text("Gider ekle")},text={Column(Modifier.heightIn(max=520.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){OutlinedTextField(title,{title=it},label={Text("Harcama adı")},singleLine=true);Text("Kategori",color=Muted);cats.chunked(3).forEach{r->Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){r.forEach{c->FilterChip(selected=category==c,onClick={category=c},label={Text(c,fontSize=10.sp)})}}};OutlinedTextField(amount,{amount=it},label={Text("Tutar (TL)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),singleLine=true);OutlinedTextField(date,{date=it},label={Text("Tarih (GG.AA.YYYY)")},singleLine=true);OutlinedTextField(note,{note=it},label={Text("Not")},singleLine=true)}},confirmButton={TextButton(enabled=title.isNotBlank()&&amount.toDoubleOrNull()!=null,onClick={onSave(Expense(title=title,category=category,amount=amount.toDoubleOrNull()?:0.0,date=date,note=note))}){Text("Kaydet")}},dismissButton={TextButton(onClick=onDismiss){Text("Vazgeç")}})
}
@Composable fun BudgetDialog(current:Double,onDismiss:()->Unit,onSave:(Double)->Unit){var v by remember{mutableStateOf(if(current>0)current.toString() else "")};AlertDialog(onDismissRequest=onDismiss,title={Text("Aylık bütçe belirle")},text={OutlinedTextField(v,{v=it},label={Text("Bütçe (TL)")},keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))},confirmButton={TextButton(enabled=v.toDoubleOrNull()!=null,onClick={onSave(v.toDoubleOrNull()?:0.0)}){Text("Kaydet")}},dismissButton={TextButton(onClick=onDismiss){Text("Vazgeç")}})}
data class MarketQuote(val name:String,val code:String,val buy:Double,val sell:Double,val change:Double?,val time:String)
@Composable fun MarketsScreen(modifier:Modifier=Modifier, coroutineScope:kotlinx.coroutines.CoroutineScope){
 var quotes by remember{mutableStateOf<List<MarketQuote>>(emptyList())};var updated by remember{mutableStateOf("")};var status by remember{mutableStateOf("Fiyatlar yükleniyor…")};var loading by remember{mutableStateOf(false)}
 suspend fun refresh(){
  loading=true
  try{
   val result=withContext(Dispatchers.IO){
    val c=(URL("https://turkishlirarates.com/data/v1/rates.json").openConnection() as HttpURLConnection).apply{connectTimeout=12000;readTimeout=12000;requestMethod="GET"}
    try{val raw=c.inputStream.bufferedReader().use{it.readText()};val j=JSONObject(raw);val market=j.getJSONObject("market");val out=mutableListOf<MarketQuote>()
     val currencies=market.getJSONArray("currencies");for(i in 0 until currencies.length()){val o=currencies.getJSONObject(i);val n=o.getJSONObject("name").optString("tr",o.optString("code"));out.add(MarketQuote(n,o.optString("code"),o.optDouble("buy"),o.optDouble("sell"),if(o.isNull("change_24h"))null else o.optDouble("change_24h"),o.optString("time")))}
     val metals=market.getJSONArray("gold_silver");for(i in 0 until metals.length()){val o=metals.getJSONObject(i);val n=o.getJSONObject("name").optString("tr",o.optString("code"));out.add(MarketQuote(n,o.optString("code"),o.optDouble("buy"),o.optDouble("sell"),if(o.isNull("change_24h"))null else o.optDouble("change_24h"),o.optString("time")))}
     Pair(out,market.optString("updated",j.optString("generated")))
    }finally{c.disconnect()}
   }
   quotes=result.first;updated=result.second;status="Kaynak: TurkishLiraRates • yaklaşık dakikalık güncelleme"
  }catch(e:Exception){status="Fiyat alınamadı: internet bağlantını kontrol edip yenile."}
  loading=false
 }
 LaunchedEffect(Unit){refresh()}
 Column(modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
  Row(verticalAlignment=Alignment.CenterVertically){Text("Piyasalar",fontSize=24.sp,fontWeight=FontWeight.Bold,color=Color.White,modifier=Modifier.weight(1f));TextButton(enabled=!loading,onClick={coroutineScope.launch{refresh()}}){Text(if(loading)"Yükleniyor" else "Yenile")}}
  Text(status,color=Aqua,fontSize=11.sp)
  if(updated.isNotBlank())Text("Son veri: $updated",color=Muted,fontSize=11.sp)
  if(quotes.isEmpty())InfoCard("Piyasa verileri",status) else LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){
   items(quotes){q->Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(14.dp)){Row(Modifier.fillMaxWidth().padding(14.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(q.name,color=Color.White,fontWeight=FontWeight.Bold);Text(q.code,color=Muted,fontSize=11.sp)};Column(horizontalAlignment=Alignment.End){Text("Alış  "+NumberFormat.getNumberInstance(Locale("tr","TR")).format(q.buy),color=Muted,fontSize=12.sp);Text("Satış "+NumberFormat.getNumberInstance(Locale("tr","TR")).format(q.sell),color=Aqua,fontWeight=FontWeight.Bold);q.change?.let{Text("%"+String.format(Locale("tr","TR"),"%.2f",it*100),color=if(it>=0)Green else Red,fontSize=11.sp)}}}}}
  }
  Text("Veri kaynağı: https://turkishlirarates.com/",color=Aqua,fontSize=12.sp)
  Text("Veriler bilgi amaçlıdır; yatırım tavsiyesi değildir. BIST hisse fiyatları bu ücretsiz kaynağa dahil değildir.",color=Muted,fontSize=10.sp)
 }
}

fun encodeExpenses(list:List<Expense>)=JSONArray().apply{list.forEach{e->put(JSONObject().apply{put("id",e.id);put("title",e.title);put("category",e.category);put("amount",e.amount);put("date",e.date);put("note",e.note)})}}.toString()
fun loadExpenses(raw:String):List<Expense> = try{val a=JSONArray(raw);(0 until a.length()).map{val o=a.getJSONObject(it);Expense(o.optString("id"),o.optString("title"),o.optString("category"),o.optDouble("amount"),o.optString("date"),o.optString("note"))}}catch(_:Exception){emptyList()}

@Composable fun MonthlyChart(incomes:List<Income>,expenses:List<Expense>){
 val months=remember(incomes,expenses){(5 downTo 0).map{offset->val c=Calendar.getInstance().apply{add(Calendar.MONTH,-offset)};val key=SimpleDateFormat("MM.yyyy",Locale("tr","TR")).format(c.time);val label=SimpleDateFormat("MMM",Locale("tr","TR")).format(c.time);Triple(label,incomes.filter{it.date.endsWith(key)}.sumOf{it.amount},expenses.filter{it.date.endsWith(key)}.sumOf{it.amount})}}
 val max=months.maxOfOrNull{maxOf(it.second,it.third)}?.coerceAtLeast(1.0)?:1.0
 Card(colors=CardDefaults.cardColors(containerColor=Panel),shape=RoundedCornerShape(18.dp)){Column(Modifier.fillMaxWidth().padding(14.dp)){Text("Son 6 ay • Gelir / Gider",color=Color.White,fontWeight=FontWeight.Bold);Spacer(Modifier.height(10.dp));Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceEvenly,verticalAlignment=Alignment.Bottom){months.forEach{m->Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.weight(1f)){Row(verticalAlignment=Alignment.Bottom,horizontalArrangement=Arrangement.spacedBy(3.dp),modifier=Modifier.height(92.dp)){Box(Modifier.width(9.dp).fillMaxHeight((m.second/max).toFloat().coerceIn(0.02f,1f)).background(Green,RoundedCornerShape(topStart=4.dp,topEnd=4.dp)));Box(Modifier.width(9.dp).fillMaxHeight((m.third/max).toFloat().coerceIn(0.02f,1f)).background(Red,RoundedCornerShape(topStart=4.dp,topEnd=4.dp)))};Text(m.first,color=Muted,fontSize=10.sp)}}};Spacer(Modifier.height(8.dp));Row(horizontalArrangement=Arrangement.spacedBy(14.dp)){Text("● Gelir",color=Green,fontSize=11.sp);Text("● Gider",color=Red,fontSize=11.sp)}}}
}
fun writeCsv(context:Context,uri:Uri,incomes:List<Income>,expenses:List<Expense>){
 try{context.contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use{w->w.write("tur;ad;kategori;tutar;tarih;not\n");incomes.forEach{w.write("gelir;${csv(it.title)};;${it.amount};${csv(it.date)};${csv(it.note)}\n")};expenses.forEach{w.write("gider;${csv(it.title)};${csv(it.category)};${it.amount};${csv(it.date)};${csv(it.note)}\n")}}}catch(_:Exception){}
}
fun csv(v:String):String = buildString { append('"'); append(v.replace("\"", "\"\"")); append('"') }
fun readExpenseCsv(context:Context,uri:Uri):List<Expense>?=try{context.contentResolver.openInputStream(uri)?.bufferedReader()?.useLines{lines->lines.drop(1).mapNotNull{line->val a=line.split(';');if(a.size>=5&&a[0].trim().equals("gider",true))Expense(title=a[1].trim('"'),category=a[2].trim('"'),amount=a[3].replace(',','.').toDoubleOrNull()?:return@mapNotNull null,date=a[4].trim('"'),note=if(a.size>5)a[5].trim('"') else "")else null}.toList()}}catch(_:Exception){null}
