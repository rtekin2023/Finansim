FINANSIM - PREMIUM / MANUEL BANKA KAYITLI SURUM

- Harici banka entegrasyonu veya demo portal bağlantısı bu sürümden çıkarılmıştır.
- Banka, hesap ve kart bilgileri kullanıcı tarafından manuel girilir.
- Kredi bilgileri: anapara/kredi tutarı, faiz oranı, aylık-yıllık faiz seçimi,
  toplam vade, aylık taksit, toplam geri ödeme, kalan taksit ve erken kapama tutarı.
- Kredi kartı bilgileri: limit, kullanılan tutar, ekstre kesim günü,
  son ödeme günü, dönem ekstresi ve asgari ödeme tutarı.
- PIN giriş ekranı ve şifreli tercih saklama kodu projede bulunmaktadır.
- Bu ZIP henüz Android cihazda derlenip uçtan uca test edilmemiştir.
- PIN ve yerel tercihlerin şifrelenmesi, tüm finansal veri dosyalarının
  bütünüyle şifrelenmiş olduğu anlamına gelmez. Gerçek finansal veri girmeden
  önce uygulama güvenlik testi yapılmalıdır.
