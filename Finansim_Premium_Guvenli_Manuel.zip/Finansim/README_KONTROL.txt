FINANSIM - KAYNAK PROJESI / HAZIRLIK PAKETI

Bu paket mevcut Finansim Android Compose projesinin düzeltilmiş kaynak kodudur.
- MainActivity.kt içindeki QuickTile tıklama bileşeni Material3 Card onClick kullanımından clickable Modifier kullanımına geçirildi.
- Yerel SharedPreferences veri saklama, gelir kaydı, borç/kart/KMH/kredi kaydı, ödeme işaretleme ve bildirim altyapısı mevcut kaynakta korunmuştur.
- Uygulama simgesi kaynakları ve GitHub Actions iş akışı pakettedir.

ÖNEMLİ DURUM:
Bu paket henüz kullanıcının istediği tüm son özellikleri tamamlamaz. Gider/bütçe grafikleri, CSV ekstre içe aktarma, tam ödeme geçmişi, piyasa API entegrasyonu ve kapsamlı kredi amortismanı bu pakette tamamlanmış değildir. Bildirimlerin gerçek cihazda ekran kapalıyken güvenilir çalışması ayrıca test edilmelidir.

APK bu ortamda derlenip doğrulanmamıştır. GitHub Actions ile derlenmeden kurulum paketi olarak kabul etmeyin.

GitHub deposuna proje dosyalarını doğrudan kök dizine çıkartın. ZIP'i yalnızca arşiv olarak depoya koymak tek başına yeterli değildir; workflow ZIP içeriğini açmalıdır.
