Finansım Android v1.1 kaynak projesi

Özellikler:
- Koyu lacivert/turkuaz arayüz ve özel uygulama simgesi
- Kredi kartı, KMH/avans hesap, ihtiyaç kredisi ve diğer borç kayıtları
- Kredi kartı limiti, ekstre kesim günü ve son ödeme günü alanları
- Tek dokunuşla Ödendi işaretleme
- Gelir kaydı (maaş, prim, ek gelir)
- Yerel cihaz depolaması
- Ödeme tarihi girilen açık hesaplar için Android yerel hatırlatma alarmı; cihaz yeniden başladığında yeniden planlama

Bildirimler: Android 13+ bildirim izni gerekir. Android üretici pil yönetimi ve Doze modu bazı bildirimleri geciktirebilir. Uygulama bankalara bağlanmaz; tutarlar kullanıcı tarafından girilir. Ödeme yapıldığı otomatik doğrulanmaz.

Derleme: GitHub Actions workflow'u, bu ZIP'in içindeki proje dosyalarını çıkartıp Gradle ile APK üretir.
