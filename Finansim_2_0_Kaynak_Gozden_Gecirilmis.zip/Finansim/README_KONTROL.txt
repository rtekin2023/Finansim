FINANSIM 2.0 KAYNAK KONTROLÜ VE DÜZELTME NOTU

Bu paket, kullanıcının gönderdiği Finansim_2_0_Gelistirme_Kaynak_Yeniden.zip içeriği temel alınarak düzenlenmiştir.

Yapılan düzeltmeler:
1. AdvancedFinance.kt dosyasının kullandığı Panel, Aqua, Muted ve Red renk sabitlerinin dosyalar arası erişim engeli kaldırıldı. Önceki GitHub Actions derlemesindeki "Cannot access ... it is private in file" hatası bu değişiklikle hedeflendi.
2. Ödeme hatırlatmalarını yeniden planlayan kodun, kayıtların gerçekte tutulduğu şifreli SharedPreferences deposunu okuması sağlandı. Önceki sürüm, boş kalan eski "finansim" deposunu okuyordu.
3. Android 13 ve üzeri sürümlerde bildirim izni uygulama açılışında isteniyor.

Korunanlar:
- Mevcut Compose ekranları ve özellik modülleri
- PIN ve kurtarma kodu akışı
- Şifreli yerel veri deposu ve AES-GCM yedekleme
- Gelir, gider, borç ve gelişmiş finans ekranları
- Mevcut Finansım uygulama ikonu ve turkuaz/lacivert tema

Doğrulama sınırı:
Bu çalışma ortamında Android SDK/Gradle kurulu olmadığından assembleDebug çalıştırılamadı. Bu nedenle APK derlemesinin başarılı olduğu iddia edilmemektedir. GitHub Actions üzerinde yeni derleme çalıştırılarak doğrulanmalıdır.
