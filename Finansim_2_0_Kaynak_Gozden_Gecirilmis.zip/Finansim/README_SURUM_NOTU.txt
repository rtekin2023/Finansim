FINANSIM 2.0-DEV - GELISTIRME KAYNAK PAKETI

Korunan mevcut özellikler:
- Turkuaz/lacivert Compose arayüzü ve özel Finansım uygulama ikonu.
- Manuel gelir, gider, borç, kredi kartı, KMH ve kredi kayıtları.
- EncryptedSharedPreferences tabanlı yerel kayıt ve CSV gider aktarımı.
- Mevcut piyasa ekranı (döviz/altın/gümüş kaynağı).
- Android yerel ödeme hatırlatmaları ve açılışta tekrar planlama.

Bu geliştirme paketine eklenenler:
- 5 dakika arka planda kaldıktan sonra uygulamanın PIN ekranına dönmesi.
- İlk PIN kurulumunda bir defa gösterilen kurtarma kodu; kodla PIN yenileme.
- Araçlar ekranı: tek tek taksit kayıtları, düzenli ödeme kayıtları, birikim hedefleri,
  varlık kayıtları, ortak harcama kayıtları, borç kapatma tahmini ve yerel finans asistanı.
- AES-256-GCM, PBKDF2-HMAC-SHA256 (210.000 iterasyon) ile parola korumalı yedek
  oluşturma ve geri yükleme. Dosya uzantısı .fnb; parola kaybedilirse yedek açılamaz.
- Google News RSS üzerinden ekonomi başlıkları ve Yahoo Finance chart uç noktası
  üzerinden sınırlı BIST izleme listesi (THYAO, ASELS, BIMAS, TUPRS, GARAN).

ÖNEMLİ SINIRLAMALAR / TEST DURUMU:
- Bu kaynak paketi bu çalışma ortamında Android SDK/Gradle bulunmadığı için APK olarak
  derlenemedi; gerçek cihaz testi yapılmadı. Kotlinc taraması Android/Compose bağımlılıkları
  bulunmadığından tam derleme değildir; yalnızca belirgin Kotlin parser hatası arandı.
- Araçlar ekranındaki taksitler ve düzenli ödemeler ayrı manuel kayıt listeleridir;
  mevcut kredi kaydından otomatik amortisman planı üretmez ve henüz her taksit için
  otomatik alarm kurmaz.
- Birikim hedefleri katkı geçmişi/ilerleme grafiği sunmaz; hedef tutarı kayıt olarak tutulur.
- Ortak harcama kayıtları kişi başı borç/alacak dağıtımı yapmaz; manuel kayıt defteridir.
- Nakit akışı tahmini 3/6/12 aylık otomatik model değildir; borç simülatörü basit sabit
  aylık faiz ve ödeme varsayımı kullanır.
- Yerel asistan üretken yapay zekâ değildir; yalnızca kayıt toplamlarını hesaplar.
- BIST ve haber kaynakları ücretsiz üçüncü taraf uç noktalarıdır; erişim, kapsam ve
  gecikme garantisi yoktur. Veriler yatırım tavsiyesi değildir.
- Şifreli yedekleme kodu kaynak seviyesinde eklendi; gerçek cihazda dosya sağlayıcılarıyla
  dışa/içe aktarma testi yapılmalıdır.
- EncryptedSharedPreferences kütüphanesi kullanılan eski alpha sürümündedir; güvenlik
  denetimi yapılmış kabul edilmemelidir.

UYGULAMA BANKALARA BAĞLANMAZ. REKLAM, ABONELİK VE ÜCRETLİ API EKLENMEMİŞTİR.
Finansal kayıtlar kullanıcı tarafından girilir. Piyasa/haber ekranı internet erişimi ister.
