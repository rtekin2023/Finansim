package com.finansim.app

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec
import java.text.SimpleDateFormat
import java.util.*

private data class FinanceItem(val id:String=UUID.randomUUID().toString(), val title:String, val amount:Double, val date:String, val detail:String="")
private fun encodeItems(items:List<FinanceItem>) = JSONArray().apply { items.forEach { put(JSONObject().put("id",it.id).put("title",it.title).put("amount",it.amount).put("date",it.date).put("detail",it.detail)) } }.toString()
private fun decodeItems(raw:String):List<FinanceItem> = try { val a=JSONArray(raw); (0 until a.length()).map { val o=a.getJSONObject(it); FinanceItem(o.optString("id"),o.optString("title"),o.optDouble("amount"),o.optString("date"),o.optString("detail")) } } catch (_:Exception) { emptyList() }

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun AdvancedFinanceScreen(context:Context, prefs:SharedPreferences) {
    val types=listOf("Taksitler","Düzenli ödemeler","Birikim hedefleri","Varlıklar","Ortak harcama","Tahmin / simülasyon","Asistan","Haberler & BIST","Yedekleme")
    var selected by remember { mutableIntStateOf(0) }
    var installments by remember { mutableStateOf(decodeItems(prefs.getString("adv_installments","[]")?:"[]")) }
    var recurring by remember { mutableStateOf(decodeItems(prefs.getString("adv_recurring","[]")?:"[]")) }
    var goals by remember { mutableStateOf(decodeItems(prefs.getString("adv_goals","[]")?:"[]")) }
    var assets by remember { mutableStateOf(decodeItems(prefs.getString("adv_assets","[]")?:"[]")) }
    var shared by remember { mutableStateOf(decodeItems(prefs.getString("adv_shared","[]")?:"[]")) }
    var showAdd by remember { mutableStateOf(false) }
    var password by remember { mutableStateOf("") }
    var backupMessage by remember { mutableStateOf("Yedekler AES-GCM ile şifrelenir; parolanı unutma.") }
    var assistantQuery by remember { mutableStateOf("") }
    var assistantAnswer by remember { mutableStateOf("Kayıtların üzerinde yerel arama ve hesaplama yapabilirim. Finansal verilerin sunucuya gönderilmez.") }
    var news by remember { mutableStateOf<List<String>>(emptyList()) }
    var stocks by remember { mutableStateOf<List<String>>(emptyList()) }
    var onlineStatus by remember { mutableStateOf("Güncel haber ve BIST verisi için yenile.") }
    var loading by remember { mutableStateOf(false) }
    val scope= rememberCoroutineScope()
    fun save(key:String, list:List<FinanceItem>) { prefs.edit().putString(key,encodeItems(list)).apply() }
    val export= rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri -> if(uri!=null) { try { val data=encryptBackup(prefs,password); context.contentResolver.openOutputStream(uri)?.use{it.write(data)}; backupMessage="Şifreli yedek oluşturuldu." } catch(e:Exception){backupMessage="Yedek oluşturulamadı: ${e.message}"} } }
    val import= rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if(uri!=null) { try { val bytes=context.contentResolver.openInputStream(uri)!!.use{it.readBytes()}; val json=decryptBackup(bytes,password); val obj=JSONObject(json); val ed=prefs.edit(); val it=obj.keys(); while(it.hasNext()){val k=it.next(); val v=obj.get(k); when(v){is String->ed.putString(k,v);is Boolean->ed.putBoolean(k,v);is Int->ed.putInt(k,v);is Long->ed.putLong(k,v);is Double->ed.putFloat(k,v.toFloat())}}; ed.apply(); installments=decodeItems(prefs.getString("adv_installments","[]")?:"[]"); recurring=decodeItems(prefs.getString("adv_recurring","[]")?:"[]"); goals=decodeItems(prefs.getString("adv_goals","[]")?:"[]"); assets=decodeItems(prefs.getString("adv_assets","[]")?:"[]"); shared=decodeItems(prefs.getString("adv_shared","[]")?:"[]"); backupMessage="Yedek geri yüklendi. Uygulamayı yeniden açman önerilir." } catch(e:Exception){backupMessage="Yedek açılamadı. Parola veya dosya hatalı."} } }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Finans araçları",fontSize=23.sp,color=Color.White)
        ScrollableTabRow(selectedTabIndex=selected,containerColor=Panel,contentColor=Aqua) { types.forEachIndexed { i,s -> Tab(selected==i,{selected=i},text={Text(s,fontSize=11.sp)}) } }
        Spacer(Modifier.height(8.dp))
        when(selected) {
            0 -> { Row { Text("Her taksit bağımsız kayıt olarak tutulur.",color=Muted,modifier=Modifier.weight(1f)); Button(onClick={showAdd=true}){Text("Taksit ekle")} }; ItemList(installments,"adv_installments",{installments=it;save("adv_installments",it)},"Taksit") }
            1 -> { Row { Text("Kira, fatura, sigorta, vergi, abonelik",color=Muted,modifier=Modifier.weight(1f)); Button(onClick={showAdd=true}){Text("Ekle")} }; ItemList(recurring,"adv_recurring",{recurring=it;save("adv_recurring",it)},"Düzenli ödeme") }
            2 -> { Row { Text("Hedef tutarını ve hedef tarihini kaydet.",color=Muted,modifier=Modifier.weight(1f)); Button(onClick={showAdd=true}){Text("Hedef ekle")} }; ItemList(goals,"adv_goals",{goals=it;save("adv_goals",it)},"Hedef") }
            3 -> { Row { Text("Nakit, araç, altın veya diğer varlıklar.",color=Muted,modifier=Modifier.weight(1f)); Button(onClick={showAdd=true}){Text("Varlık ekle")} }; ItemList(assets,"adv_assets",{assets=it;save("adv_assets",it)},"Varlık"); Text("Toplam kayıtlı varlık: ${assets.sumOf{it.amount}.toLong()} TL",color=Aqua) }
            4 -> { Row { Text("Kişi adı ve toplam harcama kaydı.",color=Muted,modifier=Modifier.weight(1f)); Button(onClick={showAdd=true}){Text("Paylaşım ekle")} }; ItemList(shared,"adv_shared",{shared=it;save("adv_shared",it)},"Ortak harcama") }
            5 -> SimulationScreen(prefs)
            6 -> { OutlinedTextField(assistantQuery,{assistantQuery=it},label={Text("Örn. bu ay giderim / toplam borcum")},modifier=Modifier.fillMaxWidth()); Button(onClick={assistantAnswer=localFinanceAnswer(assistantQuery,prefs)},modifier=Modifier.fillMaxWidth()){Text("Sor")}; Text(assistantAnswer,color=Color.White) }
            7 -> { Row { Text("İnternet üzerinden ücretsiz kaynaklarla alınır; erişim değişebilir.",color=Muted,modifier=Modifier.weight(1f)); Button(enabled=!loading,onClick={scope.launch{loading=true; try { val result=withContext(Dispatchers.IO){fetchNewsAndStocks()}; news=result.first;stocks=result.second;onlineStatus="Güncellendi: ${SimpleDateFormat("dd.MM.yyyy HH:mm",Locale("tr")).format(Date())}" }catch(e:Exception){onlineStatus="Veri alınamadı; kaynak geçici olarak erişilemiyor."};loading=false}}){Text(if(loading)"Yükleniyor" else "Yenile")} }; Text(onlineStatus,color=Aqua); Text("Ekonomi haberleri",color=Color.White); news.forEach{Text("• $it",color=Muted,fontSize=12.sp)}; Spacer(Modifier.height(8.dp)); Text("BIST izleme listesi",color=Color.White); stocks.forEach{Text(it,color=Muted,fontSize=12.sp)} }
            8 -> { OutlinedTextField(password,{password=it},label={Text("Yedek parolası (en az 8 karakter)")},modifier=Modifier.fillMaxWidth()); Button(enabled=password.length>=8,onClick={export.launch("Finansim-sifreli-yedek.fnb")},modifier=Modifier.fillMaxWidth()){Text("Şifreli yedek oluştur")}; OutlinedButton(enabled=password.length>=8,onClick={import.launch(arrayOf("application/octet-stream","*/*"))},modifier=Modifier.fillMaxWidth()){Text("Yedekten geri yükle")}; Text(backupMessage,color=Muted,fontSize=12.sp) }
        }
    }
    if(showAdd) AddFinanceItemDialog(types[selected],{showAdd=false}) { item -> when(selected){0->{installments=installments+item;save("adv_installments",installments)};1->{recurring=recurring+item;save("adv_recurring",recurring)};2->{goals=goals+item;save("adv_goals",goals)};3->{assets=assets+item;save("adv_assets",assets)};4->{shared=shared+item;save("adv_shared",shared)}};showAdd=false }
}

@Composable private fun ItemList(records:List<FinanceItem>,key:String,onChange:(List<FinanceItem>)->Unit,label:String){
    if(records.isEmpty()) Text("Henüz kayıt yok.",color=Muted,modifier=Modifier.padding(12.dp))
    LazyColumn(verticalArrangement=Arrangement.spacedBy(7.dp)){items(records,key={it.id}){x->Card(colors=CardDefaults.cardColors(containerColor=Panel)){Row(Modifier.fillMaxWidth().padding(12.dp)){Column(Modifier.weight(1f)){Text(x.title,color=Color.White);Text("${x.date} • ${x.detail}",color=Muted,fontSize=11.sp)};Text("${x.amount.toLong()} TL",color=Aqua);TextButton(onClick={onChange(records.filterNot{it.id==x.id})}){Text("Sil",color=Red)}}}}}
}

@Composable private fun AddFinanceItemDialog(title:String,onDismiss:()->Unit,onSave:(FinanceItem)->Unit){var name by remember{mutableStateOf("")};var amount by remember{mutableStateOf("")};var date by remember{mutableStateOf(SimpleDateFormat("dd.MM.yyyy",Locale("tr")).format(Date()))};var detail by remember{mutableStateOf("")};AlertDialog(onDismissRequest=onDismiss,title={Text(title+" ekle")},text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(7.dp)){OutlinedTextField(name,{name=it},label={Text("Açıklama / kişi / hedef")});OutlinedTextField(amount,{amount=it},label={Text("Tutar (TL)")});OutlinedTextField(date,{date=it},label={Text("Tarih / vade")});OutlinedTextField(detail,{detail=it},label={Text("Not / kategori")})}},confirmButton={TextButton(enabled=name.isNotBlank()&&(amount.toDoubleOrNull()?:0.0)>0,onClick={onSave(FinanceItem(title=name,amount=amount.toDoubleOrNull()?:0.0,date=date,detail=detail))}){Text("Kaydet")}},dismissButton={TextButton(onClick=onDismiss){Text("Vazgeç")}})}

@Composable private fun SimulationScreen(prefs:SharedPreferences){var monthly by remember{mutableStateOf("5000")};var debt by remember{mutableStateOf("100000")};var rate by remember{mutableStateOf("3.5")};val m=monthly.toDoubleOrNull()?:0.0;val d=debt.toDoubleOrNull()?:0.0;val r=(rate.toDoubleOrNull()?:0.0)/100.0;val months=if(m>0&&d>0){var bal=d;var n=0;while(bal>0&&n<600){bal=bal*(1+r)-m;n++;if(bal<0)bal=0.0};n}else 0;Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){Text("Borç kapatma simülatörü",color=Color.White);OutlinedTextField(debt,{debt=it},label={Text("Toplam borç TL")});OutlinedTextField(monthly,{monthly=it},label={Text("Aylık ödeme TL")});OutlinedTextField(rate,{rate=it},label={Text("Aylık faiz % (tahmini)")});Text(if(months>0)"Tahmini kapanış: $months ay" else "Tutarları gir.",color=Aqua);Text("Bu matematiksel tahmindir; bankanın gerçek faiz, vergi ve masraflarını temsil etmez.",color=Muted,fontSize=11.sp)}}

private fun localFinanceAnswer(q:String,p:SharedPreferences):String { val query=q.lowercase(Locale("tr"));val debts=loadDebts(p.getString("debts","[]")?:"[]");val inc=loadIncomes(p.getString("incomes","[]")?:"[]");val exp=loadExpenses(p.getString("expenses","[]")?:"[]");return when { "borç" in query||"borc" in query -> "Kayıtlı açık borç toplamın: ${debts.filter{!it.paid}.sumOf{it.balance}.toLong()} TL"; "gelir" in query -> "Kayıtlı toplam gelir: ${inc.sumOf{it.amount}.toLong()} TL"; "gider" in query||"harcama" in query -> "Kayıtlı toplam gider: ${exp.sumOf{it.amount}.toLong()} TL"; "taksit" in query -> "Ayrı taksit kayıtların: ${decodeItems(p.getString("adv_installments","[]")?:"[]").size}"; else -> "Borç, gelir, gider veya taksit toplamını sorabilirsin. Bu asistan yerel kayıtlar üzerinde basit hesaplama yapar; üretken yapay zekâ değildir." } }

private fun encryptBackup(prefs:SharedPreferences,password:String):ByteArray { require(password.length>=8);val salt=ByteArray(16).also{SecureRandom().nextBytes(it)};val iv=ByteArray(12).also{SecureRandom().nextBytes(it)};val spec=PBEKeySpec(password.toCharArray(),salt,210000,256);val key=SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded;spec.clearPassword();val cipher=Cipher.getInstance("AES/GCM/NoPadding");cipher.init(Cipher.ENCRYPT_MODE,SecretKeySpec(key,"AES"),GCMParameterSpec(128,iv));val json=JSONObject().apply{prefs.all.forEach{(k,v)->when(v){is String->put(k,JSONObject().put("t","s").put("v",v));is Boolean->put(k,JSONObject().put("t","b").put("v",v));is Int->put(k,JSONObject().put("t","i").put("v",v));is Long->put(k,JSONObject().put("t","l").put("v",v));is Float->put(k,JSONObject().put("t","f").put("v",v.toDouble()))}}}.toString().toByteArray(Charsets.UTF_8);val encrypted=cipher.doFinal(json);return byteArrayOf('F'.code.toByte(),'N'.code.toByte(),'B'.code.toByte(),'1'.code.toByte())+salt+iv+encrypted }
private fun decryptBackup(data:ByteArray,password:String):String { require(data.size>32&&data.copyOfRange(0,4).contentEquals(byteArrayOf(70,78,66,49)));val salt=data.copyOfRange(4,20);val iv=data.copyOfRange(20,32);val spec=PBEKeySpec(password.toCharArray(),salt,210000,256);val key=SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded;spec.clearPassword();val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.DECRYPT_MODE,SecretKeySpec(key,"AES"),GCMParameterSpec(128,iv));val obj=JSONObject(String(c.doFinal(data.copyOfRange(32,data.size)),Charsets.UTF_8));val out=JSONObject();val it=obj.keys();while(it.hasNext()){val k=it.next();val v=obj.getJSONObject(k);out.put(k,v.get("v"))};return out.toString() }


@Composable fun MarketNewsCard() {
    var headlines by remember { mutableStateOf<List<String>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Haberler yükleniyor…") }
    val scope = rememberCoroutineScope()
    suspend fun refreshNews() {
        loading = true
        try {
            val result = withContext(Dispatchers.IO) { fetchNewsAndStocks().first }
            headlines = result
            message = if (result.isEmpty()) "Şu anda haber bulunamadı. Yeniden deneyebilirsin." else "Google News RSS • Son alınan başlıklar"
        } catch (_: Exception) {
            message = "Haber servisine ulaşılamadı. İnternet bağlantını kontrol edip yenile."
        } finally { loading = false }
    }
    LaunchedEffect(Unit) { while (true) { refreshNews(); kotlinx.coroutines.delay(30 * 60 * 1000L) } }
    Card(colors=CardDefaults.cardColors(containerColor=Panel), shape=RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement=Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment=androidx.compose.ui.Alignment.CenterVertically) {
                Text("Ekonomi haberleri", color=Color.White, fontWeight=FontWeight.Bold, modifier=Modifier.weight(1f))
                TextButton(enabled=!loading, onClick={ scope.launch { refreshNews() } }) {
                    Text(if (loading) "Yükleniyor" else "Yenile", color=Aqua)
                }
            }
            Text(message, color=Muted, fontSize=11.sp)
            headlines.take(6).forEach { headline ->
                Text("• $headline", color=Color.White, fontSize=13.sp)
                HorizontalDivider(color=Panel2)
            }
        }
    }
}

internal fun fetchNewsAndStocks():Pair<List<String>,List<String>> { val headlines=mutableListOf<String>();val conn=(URL("https://news.google.com/rss/search?q=ekonomi+Türkiye&hl=tr&gl=TR&ceid=TR:tr").openConnection() as HttpURLConnection).apply{connectTimeout=10000;readTimeout=10000};try{val xml=conn.inputStream.bufferedReader().use{it.readText()};val regex=Regex("<title(?:\\s+[^>]*)?>(?:<!\\[CDATA\\[(.*?)]]>|(.*?))</title>",setOf(RegexOption.IGNORE_CASE,RegexOption.DOT_MATCHES_ALL));regex.findAll(xml).drop(1).map{(it.groups[1]?.value?:it.groups[2]?.value?:"").replace(Regex("<[^>]+>"),"").replace("&amp;","&").replace("&quot;","\"").replace("&#39;","'").trim()}.filter{it.isNotBlank()}.distinct().take(12).forEach{headlines.add(it)}}finally{conn.disconnect()};val symbols=listOf("THYAO.IS","ASELS.IS","BIMAS.IS","TUPRS.IS","GARAN.IS");val quotes=symbols.map{symbol->try{val c=(URL("https://query1.finance.yahoo.com/v8/finance/chart/$symbol?range=1d&interval=1d").openConnection() as HttpURLConnection).apply{connectTimeout=8000;readTimeout=8000;setRequestProperty("User-Agent","Mozilla/5.0")};try{val j=JSONObject(c.inputStream.bufferedReader().use{it.readText()});val result=j.getJSONObject("chart").getJSONArray("result").getJSONObject(0);val price=result.getJSONObject("meta").optDouble("regularMarketPrice");"$symbol: ${"%.2f".format(Locale.US,price)} (gecikmeli olabilir)"}finally{c.disconnect()} }catch(e:Exception){"$symbol: veri alınamadı"}};return Pair(headlines,quotes) }
